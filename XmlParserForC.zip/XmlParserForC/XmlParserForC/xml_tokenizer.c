#include "xml_tokenizer.h"

typedef xml_token_class (*TOKENIZER)( xml_tokenizer_class );
 
typedef struct xml_tokenizer_
{
	xml_token_list_class token_list;
	string_reader_class reader;

}xml_tokenizer, *xml_tokenizer_class;

xml_token_class tokenize_symbol( xml_tokenizer_class instance );
xml_token_class tokenize_new_line( xml_tokenizer_class instance );
xml_token_class tokenize_space( xml_tokenizer_class instance );
xml_token_class tokenize_dquotes( xml_tokenizer_class instance );
xml_token_class tokenize_squotes( xml_tokenizer_class instance );
xml_token_class tokenize_word( xml_tokenizer_class instance );
xml_token_class tokenize_string( xml_tokenizer_class instance);

const TOKENIZER tokenizer_table[]= {
	&tokenize_symbol,
	&tokenize_new_line,
	&tokenize_space,
	&tokenize_dquotes,
	&tokenize_squotes,
	&tokenize_word,
};

xml_tokenizer_class xml_tokenizer_construct(String string)
{
	int len = 0;

	xml_tokenizer_class instance = NULL;
	instance = NEW(xml_tokenizer);

	instance->token_list = xml_token_list_construct();
	instance->reader = string_reader_construct(string);

	printf("%s", string_reader_get_string(instance->reader));

	len = string_reader_get_length(instance->reader);
	printf("String Length : %d\n", len);

	return instance;
}

void xml_tokenizer_destruct(xml_tokenizer_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->token_list == NULL), "TokenList is NULL");
	ASSERT_FAIL((instance->reader == NULL), "StringReader is NULL");

	xml_token_list_destruct(instance->token_list);
	string_reader_destruct(instance->reader);

	DELETE(instance);
}

xml_token_list_class xml_tokenizer_parse(xml_tokenizer_class instance)
{
	int i = 0;
	char c = 0;
	xml_token_type_e type;
	xml_token_class token = NULL;
	xml_token_list_class token_list = instance->token_list;
	string_reader_class reader = instance->reader;

	while((c= string_reader_get_char(reader)) != '\0')
	{
		type = xml_token_check_type(c);
		ASSERT_FAIL((type == TK_UNKNOWN), "Unknown token %c", c);

		//printf("No.%d : %s\n", i, xml_token_get_type_string(type));

		token = tokenizer_table[type](instance);

		if(token != NULL)
		{
			xml_token_list_append_from_token(token_list, token);
		}
		else
		{
			/* Unknown  */
		}

		i++;
	}
	
	xml_token_list_print(token_list);

	return instance->token_list;
}

xml_token_class tokenize_symbol( xml_tokenizer_class instance )
{
	xml_token_class token = NULL;
	string_reader_class reader = instance->reader;
	string_info_t info = { 0, 0 };
	String str = NULL;

	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;

	str = string_reader_get_substring(reader, info);

	token = xml_token_construct(str, TK_SYMBOL);

	return token;
}

xml_token_class tokenize_new_line( xml_tokenizer_class instance )
{
	xml_token_class token = NULL;

	return token;
}

xml_token_class tokenize_space( xml_tokenizer_class instance )
{
	char c = 0;
	xml_token_type_e type;
	xml_token_class token = NULL;
	xml_token_list_class token_list = instance->token_list;
	string_reader_class reader = instance->reader;
	string_info_t info = { 0, 0 };
	String str = NULL;

	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;

	while((c= string_reader_get_char(reader)) != '\0')
	{
		type = xml_token_check_type(c);

		if(type != TK_SPACE)
		{
			str = string_reader_get_substring(reader, info);

			token = xml_token_construct(str, TK_SPACE);

			string_reader_unget_char(reader, c);

			break;
		}

		info.length++;

	}

	return token;
}

xml_token_class tokenize_dquotes( xml_tokenizer_class instance )
{
	xml_token_class token = NULL;
	string_reader_class reader = instance->reader;
	xml_token_list_class token_list = instance->token_list;
	string_info_t info = { 0, 0 };
	String str = NULL;
	xml_token_type_e type = TK_UNKNOWN;
	char c = 0;

	/* Get start of DQUOTES token and append to list */
	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;

	str = string_reader_get_substring(reader, info);
	token = xml_token_construct(str, TK_DQUOTES);
	xml_token_list_append_from_token(token_list, token);

	/* Get String Token */
	info.index = string_reader_get_index(reader);
	info.length = 0;

	/* Get String Token */
	token = tokenize_string(instance);
	xml_token_list_append_from_token(token_list, token);

	/* Get end of DQUOTES token */
	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;
	str = string_reader_get_substring(reader, info);
	token = xml_token_construct(str, TK_DQUOTES);

	return token;
}


xml_token_class tokenize_squotes( xml_tokenizer_class instance )
{
	xml_token_class token = NULL;
	string_reader_class reader = instance->reader;
	xml_token_list_class token_list = instance->token_list;
	string_info_t info = { 0, 0 };
	String str = NULL;
	xml_token_type_e type = TK_UNKNOWN;

	/* Get start of SQUOTES token and append to list */
	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;

	str = string_reader_get_substring(reader, info);
	token = xml_token_construct(str, TK_SQUOTES);
	xml_token_list_append_from_token(token_list, token);

	/* Get String Token */
	token = tokenize_string(instance);
	xml_token_list_append_from_token(token_list, token);

	/* Get end of SQUOTES token */
	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;
	str = string_reader_get_substring(reader, info);
	token = xml_token_construct(str, TK_SQUOTES);

	return token;
}

xml_token_class tokenize_word( xml_tokenizer_class instance )
{
	char c = 0;
	xml_token_type_e type;
	xml_token_class token = NULL;
	string_reader_class reader = instance->reader;
	string_info_t info = { 0, 0 };
	String str = NULL;

	info.index = string_reader_get_index(reader) - 1;
	info.length = 1;

	while((c= string_reader_get_char(reader)) != '\0')
	{
		type = xml_token_check_type(c);

		if(type != TK_WORD)
		{
			str = string_reader_get_substring(reader, info);

			if(xml_token_is_keyword(str) == TRUE)
			{
				token = xml_token_construct(str, TK_KEYWORD);
			}
			else
			{
				token = xml_token_construct(str, TK_WORD);
			}

			string_reader_unget_char(reader, c);

			break;
		}

		info.length++;

	}

	return token;
}

xml_token_class tokenize_string( xml_tokenizer_class instance)
{
	xml_token_class token = NULL;
	string_info_t info = { 0, 0 };
	String str = NULL;
	xml_token_type_e type = TK_UNKNOWN;
	char c = 0;
	string_reader_class reader = instance->reader;
	xml_token_type_e quotes_type = TK_UNKNOWN;
	xml_token_list_class token_list = instance->token_list;
	xml_token_class prev_token = NULL;

	/* Get Quotes type */
	prev_token = xml_token_list_get_last(token_list);
	quotes_type = xml_token_get_type(prev_token);
	ASSERT_FAIL(((quotes_type != TK_DQUOTES) && (quotes_type != TK_SQUOTES)) , "Previous token is not Quotes : %d", quotes_type);

	info.index = string_reader_get_index(reader);
	info.length = 0;

	while((c= string_reader_get_char(reader)) != '\0')
	{
		type = xml_token_check_type(c);

		if(type == quotes_type)
		{
			str = string_reader_get_substring(reader, info);
			token = xml_token_construct(str, TK_STRING);
			break;
		}

		info.length++;
	}

	return token;
}