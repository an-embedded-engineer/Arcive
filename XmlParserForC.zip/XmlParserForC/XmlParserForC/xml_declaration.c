#include "xml_declaration.h"

typedef struct xml_declaration_
{
	String version;
	String encoding;
	String standalone;
}xml_declaration, *xml_declaration_class;


xml_declaration_class xml_declaration_construct(String ver, String enc, String std)
{
	xml_declaration_class instance = NULL;
	ASSERT_FAIL((ver == NULL), "Version is NULL");
	ASSERT_FAIL((enc == NULL), "Encoding is NULL");
	ASSERT_FAIL((std == NULL), "Standalone is NULL");

	instance = NEW(xml_declaration);
	
	COPY_STRING(instance->version, ver);
	COPY_STRING(instance->encoding, enc);
	COPY_STRING(instance->standalone, std);

	return instance;
}

void xml_declaration_destruct(xml_declaration_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->version == NULL), "Version is NULL");
	ASSERT_FAIL((instance->encoding == NULL), "Encoding is NULL");
	ASSERT_FAIL((instance->standalone == NULL), "Standalone is NULL");

	DELETE(instance->version);
	DELETE(instance->encoding);
	DELETE(instance->standalone);

	DELETE(instance);

}

String xml_declaration_get_version(xml_declaration_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->version == NULL), "Version is NULL");

	return instance->version;
}

String xml_declaration_get_encoding(xml_declaration_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->encoding == NULL), "Encoding is NULL");

	return instance->encoding;
}

String xml_declaration_get_standalone(xml_declaration_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->standalone == NULL), "Standalone is NULL");

	return instance->standalone;
}

void xml_declaration_print(xml_declaration_class instance)
{
	String ver, enc, std;
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->version == NULL), "Version is NULL");
	ASSERT_FAIL((instance->encoding == NULL), "Encoding is NULL");
	ASSERT_FAIL((instance->standalone == NULL), "Standalone is NULL");

	ver = instance->version;
	enc = instance->encoding;
	std = instance->standalone;
	
	printf("<?xml ");
	(strlen(ver)!= 0) ? printf("version=\"%s\" ", ver) : printf("");
	(strlen(enc)!= 0) ? printf("encoding=\"%s\" ", enc) : printf("");
	(strlen(std)!= 0) ? printf("standalone=\"%s\" ", std) : printf("");
	printf("?>\n");
}