#include "util.h"

typedef struct xml_declaration_* xml_declaration_class;

xml_declaration_class xml_declaration_construct(String ver, String enc, String std);
void xml_declaration_destruct(xml_declaration_class instance);
void xml_declaration_print(xml_declaration_class instance);
String xml_declaration_get_version(xml_declaration_class instance);
String xml_declaration_get_encoding(xml_declaration_class instance);
String xml_declaration_get_standalone(xml_declaration_class instance);
void xml_declaration_print(xml_declaration_class instance);

