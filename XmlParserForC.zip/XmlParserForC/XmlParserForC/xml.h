#pragma once
#include "util.h"
#include "xml_declaration.h"
#include "xml_elements.h"

typedef struct xml_* xml_class;

xml_class xml_construct(xml_declaration_class dec, xml_elements_class elements);
void xml_destruct(xml_class instance);
void xml_print(xml_class instance);
