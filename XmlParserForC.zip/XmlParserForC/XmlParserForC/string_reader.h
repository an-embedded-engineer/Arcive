#pragma once
#include "util.h"

typedef struct string_reader_* string_reader_class;

typedef struct string_info_t_
{
	UW index;
	UW length;
}string_info_t;

string_reader_class string_reader_construct(String string);
void string_reader_destruct(string_reader_class instance);
const String string_reader_get_string(string_reader_class instance);
const String string_reader_get_substring(string_reader_class instance, string_info_t info);
UW string_reader_get_length(string_reader_class instance);
UW string_reader_get_index(string_reader_class instance);
char string_reader_get_char(string_reader_class instance);
void string_reader_unget_char(string_reader_class instance, char c);
void string_reader_reset_index(string_reader_class instance);
