#pragma once
#include "util.h"
#include "xml_token.h"

typedef struct xml_token_list_* xml_token_list_class;

xml_token_list_class xml_token_list_construct(void);
void xml_token_list_destruct(xml_token_list_class instance);
void xml_token_list_append_from_value(xml_token_list_class instance, String value, xml_token_type_e type);
void xml_token_list_append_from_token(xml_token_list_class instance, xml_token_class token);
void xml_token_list_clear(xml_token_list_class instance);
xml_token_class xml_token_list_get_next(xml_token_list_class instance);
xml_token_class xml_token_list_get_prev(xml_token_list_class instance);
xml_token_class xml_token_list_get_first(xml_token_list_class instance);
xml_token_class xml_token_list_get_last(xml_token_list_class instance);
xml_token_class xml_token_list_get_current(xml_token_list_class instance);
void xml_token_list_print(xml_token_list_class instance);