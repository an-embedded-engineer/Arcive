#include "xml_element.h"

xml_element xml_element_construct(String tag, String value)
{
	xml_element instance = NULL;
	ASSERT_FAIL((tag == NULL), "Tag is NULL");
	ASSERT_FAIL((value == NULL), "Value is NULL");
	
	instance = NEW(xml_element_t);

	COPY_STRING(instance->tag, tag);
	COPY_STRING(instance->value, value);

	return instance;
}

void xml_element_destruct(xml_element instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->tag == NULL), "Tag is NULL");
	ASSERT_FAIL((instance->value == NULL), "Value is NULL");

}
