#pragma once
#include "util.h"
#include "xml.h"

typedef struct xml_parser_* xml_parser_class;

xml_parser_class xml_parser_construct(void);
void xml_parser_destruct(xml_parser_class instance);
xml_class xml_parser_parse(xml_parser_class instance);
void xml_parser_print(xml_parser_class instance);
