#include "util.h"

void* alloc_memory(size_t size)
{
	return malloc(size);
}

void release_memory(void* address)
{
	free(address);
}