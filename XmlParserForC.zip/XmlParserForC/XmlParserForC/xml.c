#include "xml.h"

/* Private members */
typedef struct xml_
{
	xml_declaration_class declaration;
	xml_elements_class elements;
}xml, *xml_class;

xml_class xml_construct(xml_declaration_class dec, xml_elements_class elements)
{
	xml_class instance = NEW(xml);
	instance->declaration = dec;
	instance->elements = elements;

	return instance;
}

void xml_destruct(xml_class instance)
{
	xml_declaration_destruct(instance->declaration);
	xml_elements_destruct(instance->elements);

	DELETE(instance);
}

void xml_print(xml_class instance)
{
	xml_declaration_print(instance->declaration);
	xml_elements_print(instance->elements);
}
