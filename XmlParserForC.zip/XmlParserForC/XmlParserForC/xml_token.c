#include "xml_token.h"
#include <ctype.h>

#define CHAR_DQUOTES '\"'
#define CHAR_SQUOTES '\''

typedef xml_token_type_e (*TOKEN_CHECK)( char c );

BOOL is_single_byte( char c );
BOOL is_multi_byte( char c );

xml_token_type_e chk_multi_byte( char c );
xml_token_type_e chk_symbol( char c );
xml_token_type_e chk_new_line( char c );
xml_token_type_e chk_space( char c );
xml_token_type_e chk_double_quotes( char c );
xml_token_type_e chk_single_quotes( char c );
xml_token_type_e chk_word( char c );

xml_token_type_e chk_keyword( String c );

/* Private members */
typedef struct xml_token_
{
	String value;
	xml_token_type_e type;
	
}xml_token, *xml_token_class;

static const String xml_token_type_string_table[] = 
{
	"TK_SYMBOL",     // < > ? ! - = /
	"TK_NEW_LINE",   // \r \n
	"TK_SPACE",      // ' ' or '\t'
	"TK_DQUOTES",    // \"
	"TK_SQUOTES",    // \'
	"TK_WORD",       // Some word
	"TK_KEYWORD",    // xml
	"TK_STRING",     // "STRING" or 'STRING'
	"TK_START",      // Start of XML
	"TK_END",        // End of XML
	"TK_UNKNOWN",    // Unknown token
};

static const char xml_token_symbol[] = 
{
	'<', '>', '?', '!', '-', '=', '/',
};

static const char xml_token_new_line[] = 
{
	'\r', '\n',
};

static const String xml_token_keyword[] = 
{
	"xml",
};

const TOKEN_CHECK token_checker_table[]= {
	&chk_multi_byte,
	&chk_symbol, 
	&chk_new_line, 
	&chk_space, 
	&chk_double_quotes, 
	&chk_single_quotes, 
	&chk_word, 
};

xml_token_type_e xml_token_check_type(char c)
{
	int i = 0;
	int cnt = ELEMENT_COUNT(token_checker_table);
	xml_token_type_e type = TK_UNKNOWN;

	for(i = 0; i < cnt; i++)
	{
		type = token_checker_table[i](c);
		if(TK_UNKNOWN != type)
		{
			break;
		}
	}
	return type;
}

String xml_token_get_type_string(xml_token_type_e type)
{
	return xml_token_type_string_table[type];
}

BOOL xml_token_is_keyword(String value)
{
	BOOL is_keyword = FALSE;
	ASSERT_FAIL((value == NULL), "Instance is NULL");

	if(TK_KEYWORD == chk_keyword(value))
	{
		is_keyword = TRUE;
	}

	return is_keyword;
}


xml_token_class xml_token_construct(String value, xml_token_type_e type)
{
	xml_token_class instance = NULL;

	ASSERT_FAIL(value == NULL, "String Value is NULL");

	instance = NEW(xml_token);

	COPY_STRING(instance->value, value);
	instance->type = type;

	return instance;
}

void xml_token_destruct(xml_token_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->value == NULL), "String Value is NULL");

	RELEASE(instance->value);
	DELETE(instance);
}

const String xml_token_get_value(xml_token_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_WARNING((instance->value == NULL), "String Value is NULL");

	return (const String)instance->value;
}

xml_token_type_e xml_token_get_type(xml_token_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	return instance->type;
}

void xml_token_print(xml_token_class instance)
{
	String type_str = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	type_str = xml_token_get_type_string(instance->type);
	printf("Type : %-13s  |  Value : \"%s\"\n", type_str, instance->value);
}

BOOL is_single_byte( char c )
{
	BOOL is_single = FALSE;

	if((c & 0x80) == 0)
	{
		is_single = TRUE;
	}

	return is_single;
}

BOOL is_multi_byte( char c )
{
	BOOL is_multi = FALSE;

	if((c & 0x80) != 0)
	{
		is_multi = TRUE;
	}

	return is_multi;
}

xml_token_type_e chk_multi_byte( char c )
{
	xml_token_type_e type = TK_UNKNOWN;
	if(is_multi_byte(c) == TRUE)
	{
		type = TK_WORD;
	}
	return type;
}

xml_token_type_e chk_symbol( char c )
{
	int i = 0;
	int cnt = ELEMENT_COUNT(xml_token_symbol);
	xml_token_type_e type = TK_UNKNOWN;

	for(i = 0; i < cnt; i++)
	{
		if(xml_token_symbol[i] == c)
		{
			type = TK_SYMBOL;
			break;
		}
	}

	return type;
}

xml_token_type_e chk_new_line( char c )
{
	int i = 0;
	int cnt = ELEMENT_COUNT(xml_token_new_line);
	xml_token_type_e type = TK_UNKNOWN;

	for(i = 0; i < cnt; i++)
	{
		if(xml_token_new_line[i] == c)
		{
			type = TK_NEW_LINE;
			break;
		}
	}

	return type;
}

xml_token_type_e chk_space( char c )
{
	xml_token_type_e type = TK_UNKNOWN;

	if(isspace(c))
	{
		type = TK_SPACE;
	}

	return type;
}

xml_token_type_e chk_double_quotes( char c )
{
	xml_token_type_e type = TK_UNKNOWN;

	if(c == CHAR_DQUOTES)
	{
		type = TK_DQUOTES;
	}

	return type;
}

xml_token_type_e chk_single_quotes( char c )
{
	xml_token_type_e type = TK_UNKNOWN;

	if(c == CHAR_SQUOTES)
	{
		type = TK_SQUOTES;
	}

	return type;
}

xml_token_type_e chk_word( char c )
{
	xml_token_type_e type = TK_UNKNOWN;

	if(isgraph(c))
	{
		type = TK_WORD;
	}

	return type;
}

xml_token_type_e chk_keyword( String str )
{
	int i = 0;
	int cnt = ELEMENT_COUNT(xml_token_keyword);
	xml_token_type_e type = TK_UNKNOWN;

	for(i = 0; i < cnt; i++)
	{
		if(strcmp(xml_token_keyword[i], str) == 0)
		{
			type = TK_KEYWORD;
			break;
		}
	}
	return type;
}