#include "xml_elements.h"

typedef struct xml_childs_
{
	xml_elements_class child;
	struct xml_childs_* next;
}xml_childs, *xml_childs_class;

typedef struct xml_elements_
{
	xml_element_type_e type;
	xml_element element;
	xml_childs_class child_top;
	xml_childs_class child_last;
	void (*add)(struct xml_elements_* instance ,struct xml_elements_* child);
    void (*print)(struct xml_elements_* instance ,int n);
}xml_elements, *xml_elements_class;

void elements_print(xml_elements_class instance, int n);
void child_print(xml_elements_class instance, int n);

void elements_add(xml_elements_class instance, xml_elements_class child);
void child_add(xml_elements_class instance, xml_elements_class child);

xml_childs_class xml_childs_construct(xml_elements_class element);
void xml_childs_destruct(xml_childs_class childs);

void print_indent(int n);

xml_elements_class xml_elements_construct(xml_element_type_e type, String tag, String value)
{
	xml_elements_class instance = NULL;

	ASSERT_FAIL((tag == NULL), "Tag is NULL");
	ASSERT_FAIL((value == NULL), "Value is NULL");

	instance = NEW(xml_elements);

	instance->type = type;
	instance->element = xml_element_construct(tag, value);
	instance->child_top = NULL;
	instance->child_last = NULL;

	switch(type)
	{
	case XML_ELEMENTS:
		instance->add = &elements_add;
		instance->print = &elements_print;
		break;
	case XML_ELEMENT_CHILD:
		instance->add = &child_add;
		instance->print = &child_print;
		break;
	}

	return instance;
}

void xml_elements_destruct(xml_elements_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	xml_elements_clear_childs(instance);	

	instance = NULL;
	return;
}

void xml_elements_print(xml_elements_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	instance->print(instance, 0);
}

void xml_elements_add(xml_elements_class instance, xml_elements_class child)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	instance->add(instance, child);
}

void xml_elements_clear_childs(xml_elements_class instance)
{
	xml_childs_class childs = NULL;
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	if(instance->type == XML_ELEMENTS)
	{
		childs = instance->child_top;
		while(childs != NULL)
		{
			xml_elements_destruct(childs->child);
			childs = childs->next;
		}
		instance->child_top->child = NULL;
		xml_childs_destruct(instance->child_top);
	}

	printf("Delete : <%s>\n", instance->element->tag);

	xml_element_destruct(instance->element);
	DELETE(instance);
}


void print_indent(int n) 
{
	int i = 0;
	for( i = 0; i < n; i++)
	{
		printf("  ");
	}
    return;
}

void elements_add(xml_elements_class instance, xml_elements_class child)
{
	xml_childs_class childs = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((child == NULL), "Child Element is NULL");

	childs = xml_childs_construct(child);

	if(instance->child_top == NULL)
	{
		instance->child_top = childs;
		instance->child_last = childs;
	}
	else
	{
		instance->child_last->next = childs;
		instance->child_last = childs;
	}
	return;
}

void child_add(xml_elements_class instance, xml_elements_class child)
{
	xml_element element = child->element;

	FATAL_ERROR("Element cannnot add to child object : <%s>%s</%s>\n", element->tag, element->value, element->tag);
}

void elements_print(xml_elements_class instance, int n)
{
	xml_elements_class elements = NULL;
	xml_childs_class childs = NULL;
	xml_element element = NULL;
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	childs = instance->child_top;
	element = instance->element;

	print_indent(n);
	printf("<%s>%s\n", element->tag, element->value);
	while(childs != NULL)
	{
		n++;
		elements = childs->child;
		elements->print(elements, n);
		--n;
		childs = childs->next;	
	}
	print_indent(n);
	printf("</%s>\n", element->tag);
	return;
}

void child_print(xml_elements_class instance, int n)
{
	xml_element element = instance->element;

	print_indent(n);
	if(strlen(element->value) != 0)
	{
		printf("<%s>%s</%s>\n", element->tag, element->value, element->tag);
	}
	else
	{
		printf("<%s/>\n", element->tag);
	}

    return;
}

xml_childs_class xml_childs_construct(xml_elements_class element)
{
	xml_childs_class childs = NULL;
	childs = NEW(xml_childs);
	childs->child = element;
	childs->next = NULL;

	return childs;
}

void xml_childs_destruct(xml_childs_class childs)
{
	xml_childs_class next = NULL;
	ASSERT_FAIL((childs == NULL), "Childs is NULL");
	ASSERT_FAIL((childs->child != NULL), "Childs has child object");

	while( childs != NULL )
	{
		next = childs->next;
		DELETE(childs);
		childs = next;
	}
	return;
}
