#include "xml_tokenizer.h"
#include "xml_parser.h"

fpos_t GetFileSize(FILE* fp);
String GetString(FILE* fp);

int main(void)
{
	const char* fname_r = "test.xml"; 
	FILE* fp_r = NULL;
	String string = NULL;
	xml_tokenizer_class tokenizer = NULL;
	xml_parser_class parser = NULL;
	xml_class xml = NULL;

	parser = xml_parser_construct();
	xml = xml_parser_parse(parser);
	xml_print(xml);
	xml_parser_destruct(parser);

	if((fp_r = fopen(fname_r, "r")) != NULL)
	{
		string = GetString(fp_r);

		tokenizer = xml_tokenizer_construct(string);

		xml_tokenizer_parse(tokenizer);

		xml_tokenizer_destruct(tokenizer);

		RELEASE(string);
	}
	else
	{
		printf("%s cannot open\n", fname_r);
	}

	fclose(fp_r);

	

	return 0;
}

fpos_t GetFileSize(FILE* fp)
{
	fpos_t fsize = 0;
	fpos_t fsizeb = 0;
	fsizeb = fseek(fp, 0, SEEK_END);
	fgetpos(fp, &fsize);
	fseek(fp, fsizeb, SEEK_SET);
	printf("File Length : %u\n", fsize);

	return fsize;
}

String GetString(FILE* fp)
{
	fpos_t fsize = 0;
	String buffer = NULL;
	B* p;
	B c;

	fsize = GetFileSize(fp);
	buffer = NEW_STRING(fsize);
	memset(buffer, 0, sizeof(buffer));
	p = (B*)buffer;

	while((c = fgetc(fp)) != EOF)
	{
		*p = c;
		p++;
	}

	*p = '\0';

	return buffer;
}
