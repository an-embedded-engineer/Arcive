#pragma once
#include "util.h"

typedef struct xml_token_* xml_token_class;

typedef enum xml_token_type_e_
{
	TK_SYMBOL,     // < > ? ! - = /
	TK_NEW_LINE,   // \r \n
	TK_SPACE,      // ' ' or '\t'
	TK_DQUOTES,    // \"
	TK_SQUOTES,    // \'
	TK_WORD,       // Some word
	TK_KEYWORD,    // xml
	TK_STRING,     // "STRING" or 'STRING'
	TK_START,      // Start of XML
	TK_END,        // End of XML
	TK_UNKNOWN,    // Unknown token
}xml_token_type_e;

/* Static Method */
xml_token_type_e xml_token_check_type(char c);
String xml_token_get_type_string(xml_token_type_e type);
BOOL xml_token_is_keyword(String value);

/* Instance Public Method */
xml_token_class xml_token_construct(String value, xml_token_type_e type);
void xml_token_destruct(xml_token_class instance);
const String xml_token_get_value(xml_token_class instance);
xml_token_type_e xml_token_get_type(xml_token_class instance);
void xml_token_print(xml_token_class instance);