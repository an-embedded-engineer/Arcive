#include "string_reader.h"

typedef struct string_reader_
{
	String string;
	UW length;
	UW index;
}string_reader, *string_reader_class;

string_reader_class string_reader_construct(String string)
{
	string_reader_class instance;

	ASSERT_FAIL((string == NULL), "String is NULL");

	instance = NEW(string_reader);
	COPY_STRING(instance->string, string);
	instance->length = strlen(instance->string);
	instance->index = 0;

	return instance;
}

void string_reader_destruct(string_reader_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->string == NULL), "String is NULL");

	RELEASE(instance->string);
	DELETE(instance);
}

const String string_reader_get_string(string_reader_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	return instance->string;
}

const String string_reader_get_substring(string_reader_class instance, string_info_t info)
{
	String  str = NULL;
	const char* offset = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((info.index >= instance->length), "Index is out of bounds");
	ASSERT_FAIL(((info.index + info.length) > instance->length), "Length is too large");

	offset  = &instance->string[info.index];

	COPY_N_STRING(str, offset, info.length);

	return str;
}

UW string_reader_get_length(string_reader_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	return instance->length;
}

UW string_reader_get_index(string_reader_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	return instance->index;
}

char string_reader_get_char(string_reader_class instance)
{
	UW index = 0;
	char c = 0;
	
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	index = instance->index;
	c =instance->string[index];
	instance->index++;

	return c;
}

void string_reader_unget_char(string_reader_class instance, char c)
{	
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->string[instance->index-1] != c), "Character is different");

	instance->index--;
}


void string_reader_reset_index(string_reader_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	instance->index = 0;
}
