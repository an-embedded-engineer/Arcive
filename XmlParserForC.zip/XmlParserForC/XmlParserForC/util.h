#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char UB;
typedef signed char B;
typedef char* String;
typedef unsigned short UH;
typedef signed short H;
typedef unsigned int UW;
typedef signed int W;
typedef unsigned int BOOL;

#define TRUE  (1U)
#define FALSE (0U)

/* Utility for Class */
#define NEW(type) (type*)alloc_memory(sizeof(type))
#define DELETE(instance) release_memory(instance)

/* Utility for Array */
#define RELEASE(buffer) release_memory(buffer)
#define ELEMENT_COUNT(array) (sizeof(array) / sizeof(array[0]))

/* Utility for String */
#define NEW_STRING(size) (String)alloc_memory(size+1)
#define COPY_STRING(dest, string)            \
	if(string != NULL)                       \
	{                                        \
		dest = NEW_STRING(strlen(string));   \
		strcpy(dest, string);                \
	}                                        \
	else                                     \
	{                                        \
		dest = string;                       \
	}                                        \

#define COPY_N_STRING(dest, string, length)  \
	if(string != NULL)                       \
	{                                        \
		dest = NEW_STRING(length);           \
		strncpy(dest, string, length);       \
		dest[length] = '\0';                 \
	}                                        \
	else                                     \
	{                                        \
		dest = NULL;                         \
	}                                        \

/* Utility for Debug */

//#define DEBUG_LOG_ENABLE

#define LOG_ERROR(format, ...) \
	printf("[ERROR][%s(L.%d)] " format, __FUNCTION__, __LINE__, __VA_ARGS__);

#define LOG_WARNING(format, ...) \
	printf("[WARNING][%s(L.%d)] " format, __FUNCTION__, __LINE__, __VA_ARGS__);

#define LOG_INFO(format, ...) \
	printf("[INFO][%s(L.%d)] " format, __FUNCTION__, __LINE__, __VA_ARGS__);

#ifdef DEBUG_LOG_ENABLE
	#define DEBUG_LOG(format, ...) \
		printf("[DEBUG][%s(L.%d)] " format, __FUNCTION__, __LINE__, __VA_ARGS__);
#else
	#define DEBUG_LOG(format, ...) 
#endif

#define FATAL_ERROR(message, ...)               \
		LOG_ERROR(message "\n", __VA_ARGS__);   \
		exit(-1);                               \

#define ASSERT_FAIL(exp, message, ...)          \
	if((exp) != 0)                              \
	{                                           \
		FATAL_ERROR(message, __VA_ARGS__);		\
	}                                           \
	else                                        \
	{                                           \
		DEBUG_LOG("[" #exp "] check pass\n");   \
	}                                           \

#define ASSERT_WARNING(exp, message, ...)       \
	if((exp) != 0)                              \
	{                                           \
		LOG_WARNING(message "\n", __VA_ARGS__); \
	}                                           \
	else                                        \
	{                                           \
		DEBUG_LOG("[" #exp "] check pass\n");   \
	}                                           \

void* alloc_memory(size_t size);
void release_memory(void* address);