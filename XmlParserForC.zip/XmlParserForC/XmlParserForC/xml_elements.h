#pragma once
#include "util.h"
#include "xml_element.h"

typedef struct xml_elements_* xml_elements_class;

typedef enum xml_element_type_e_ 
{
	XML_ELEMENT_CHILD,
	XML_ELEMENTS,
}xml_element_type_e;

xml_elements_class xml_elements_construct(xml_element_type_e type, String tag, String value);
void xml_elements_destruct(xml_elements_class instance);
void xml_elements_add(xml_elements_class instance, xml_elements_class child);
void xml_elements_clear_childs(xml_elements_class instance);
void xml_elements_print(xml_elements_class instance);

