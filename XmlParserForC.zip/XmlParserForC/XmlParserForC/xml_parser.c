#include "xml_parser.h"

typedef struct xml_parser_
{
	xml_class xml;
}xml_parser, *xml_parser_class;

xml_parser_class xml_parser_construct(void)
{
	xml_parser_class instance = NULL;
	xml_class xml = NULL;
	xml_declaration_class declaration = NULL;
	xml_elements_class element1 = NULL;
	xml_elements_class element2 = NULL;
	xml_elements_class element3 = NULL;
	xml_elements_class element4 = NULL;
	
	instance = NEW(xml_parser);

	declaration = xml_declaration_construct("1.1", "UTF-8", "yes");
	element1 = xml_elements_construct(XML_ELEMENTS, "test1", "");
	xml_elements_add(element1, xml_elements_construct(XML_ELEMENT_CHILD, "child1-1", "child1-1"));
	xml_elements_add(element1, xml_elements_construct(XML_ELEMENT_CHILD, "child1-2", "child1-2"));
	xml_elements_add(element1, xml_elements_construct(XML_ELEMENT_CHILD, "child1-3", "child1-3"));
	element2 = xml_elements_construct(XML_ELEMENTS, "test2", "");
	xml_elements_add(element2, xml_elements_construct(XML_ELEMENT_CHILD, "child2-1", "child2-1"));
	xml_elements_add(element2, xml_elements_construct(XML_ELEMENT_CHILD, "child2-2", "child2-2"));
	xml_elements_add(element2, xml_elements_construct(XML_ELEMENT_CHILD, "child2-3", "child2-3"));
	element4 = xml_elements_construct(XML_ELEMENT_CHILD, "test4", "");
	element3 = xml_elements_construct(XML_ELEMENTS, "test", "");
	xml_elements_add(element3, element1);
	xml_elements_add(element3, element2);
	xml_elements_add(element3, element4);

	instance->xml = xml_construct(declaration, element3);
	return instance;
}

void xml_parser_destruct(xml_parser_class instance)
{
	xml_destruct(instance->xml);

	DELETE(instance);
}

xml_class xml_parser_parse(xml_parser_class instance)
{
	return instance->xml;
}

void xml_parser_print(xml_parser_class instance)
{
	xml_print(instance->xml);
}
