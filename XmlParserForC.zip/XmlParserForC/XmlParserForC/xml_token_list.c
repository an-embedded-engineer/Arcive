#include "xml_token_list.h"

typedef struct xml_token_list_t_
{
	xml_token_class token;
	struct xml_token_list_t_* prev;
	struct xml_token_list_t_* next;
}xml_token_list_t;

typedef struct xml_token_list_
{
	xml_token_list_t* root;
	xml_token_list_t* current;
	xml_token_list_t* tail;
	
}xml_token_list, *xml_token_list_class;

/* private method declaration */
static void list_insert_item(xml_token_list_class instance, xml_token_list_t* before, xml_token_list_t* item);
static void list_remove_item(xml_token_list_class instance, xml_token_list_t* item);
static xml_token_list_t* create_new_item_from_value(String value, xml_token_type_e type);
static xml_token_list_t* create_new_item(xml_token_class token);
static void delete_item(xml_token_list_t* item);
static void item_print(xml_token_list_t* item);


xml_token_list_class xml_token_list_construct(void)
{
	xml_token_list_class instance = NEW(xml_token_list);

	instance->root = create_new_item_from_value("root", TK_START);
	instance->tail = create_new_item_from_value("tail", TK_END);
	
	instance->root->next = instance->tail;
	instance->tail->prev = instance->root;
	instance->current = instance->root;

	return instance;
}

void xml_token_list_destruct(xml_token_list_class instance)
{
	xml_token_list_clear(instance);
	ASSERT_FAIL((instance->root->next != instance->tail), "Root item has next item");
	ASSERT_FAIL((instance->tail->prev != instance->root), "Root item has next item");

	instance->root->next = NULL;
	instance->tail->prev = NULL;

	delete_item(instance->tail);
	delete_item(instance->root);
	DELETE(instance);
}

void xml_token_list_append_from_value(xml_token_list_class instance, String value, xml_token_type_e type)
{
	xml_token_class token;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_WARNING((value == NULL), "String is NULL");

	token = xml_token_construct(value, type);

	xml_token_list_append_from_token(instance, token);
}

void xml_token_list_append_from_token(xml_token_list_class instance, xml_token_class token)
{
	xml_token_list_t* item = NULL;
	xml_token_list_t* before = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_WARNING((token == NULL), "New Item is NULL");

	before = instance->tail->prev;
	item = create_new_item(token);
	list_insert_item(instance, before, item);
}

void xml_token_list_clear(xml_token_list_class instance)
{
	xml_token_list_t* current = NULL;
	xml_token_list_t* item = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	current = instance->root->next;

	while(current != instance->tail)
	{
		item = current;
		current = current->next;

		list_remove_item(instance, item);
	}
}

xml_token_class xml_token_list_get_first(xml_token_list_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_WARNING((instance->root->next == instance->tail), "First item  is Tail");

	instance->current = instance->root->next;

	return instance->current->token;
}

xml_token_class xml_token_list_get_last(xml_token_list_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->tail->prev == instance->root), "Last item is Root");

	instance->current = instance->tail->prev;
	return instance->current->token;
}

xml_token_class xml_token_list_get_next(xml_token_list_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->current == instance->tail), "Current item is Tail");

	instance->current = instance->current->next;
	return instance->current->token;
}

xml_token_class xml_token_list_get_prev(xml_token_list_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->current == instance->root), "Current item is Root");

	instance->current = instance->current->prev;
	return instance->current->token;
}

xml_token_class xml_token_list_get_current(xml_token_list_class instance)
{
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((instance->current == NULL), "Current item is NULL");

	return instance->current->token;
}

void xml_token_list_print(xml_token_list_class instance)
{
	xml_token_list_t* current = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");

	current = instance->root->next;

	while(current != instance->tail)
	{
		item_print(current);

		current = current->next;
	}
}


/* Private Method */
static xml_token_list_t* create_new_item_from_value(String value, xml_token_type_e type)
{
	xml_token_class token = xml_token_construct(value, type);
	xml_token_list_t* item =create_new_item(token);

	return item;
}

static xml_token_list_t* create_new_item(xml_token_class token)
{
	xml_token_list_t* item = NEW(xml_token_list_t);

	item->token  = token;
	item->prev = NULL;
	item->next = NULL;

	return item;
}

static void delete_item(xml_token_list_t* item)
{
	ASSERT_FAIL((item->next != NULL), "List item has next item");
	ASSERT_FAIL((item->prev != NULL), "List item has previous item");

	xml_token_destruct(item->token);
	DELETE(item);
}

static void list_insert_item(xml_token_list_class instance, xml_token_list_t* before, xml_token_list_t* item)
{
	xml_token_list_t* next = NULL;
	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((before == NULL), "Before Item is NULL");
	ASSERT_WARNING((item == NULL), "New Item is NULL");

	next = before->next;
	
	before->next = item;
	item->prev = before;
	
	item->next = next;
	next->prev = item;
}

static void list_remove_item(xml_token_list_class instance, xml_token_list_t* item)
{
	xml_token_list_t* before = NULL;
	xml_token_list_t* next = NULL;

	ASSERT_FAIL((instance == NULL), "Instance is NULL");
	ASSERT_FAIL((item == NULL), "Item is NULL");
	ASSERT_FAIL((item == instance->root), "Item is Root Object");
	ASSERT_FAIL((item == instance->tail), "Item is Tail Object");

	before = item->prev;
	next = item->next;

	before->next = next;
	next->prev = before;

	item->next = NULL;
	item->prev = NULL;

	delete_item(item);

}

static void item_print(xml_token_list_t* item)
{
	ASSERT_FAIL((item == NULL), "Item is NULL");

	xml_token_print(item->token);
}