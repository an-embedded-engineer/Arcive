#pragma once
#include "util.h"

typedef struct xml_element_t_
{
	String tag;
	String value;
}xml_element_t, *xml_element;

xml_element xml_element_construct(String tag, String value);
void xml_element_destruct(xml_element instance);
