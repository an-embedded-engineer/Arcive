#pragma once
#include "util.h"
#include "xml_token.h"
#include "xml_token_list.h"
#include "string_reader.h"

typedef struct xml_tokenizer_* xml_tokenizer_class;

xml_tokenizer_class xml_tokenizer_construct(String string);
void xml_tokenizer_destruct(xml_tokenizer_class instance);
xml_token_list_class xml_tokenizer_parse(xml_tokenizer_class instance);