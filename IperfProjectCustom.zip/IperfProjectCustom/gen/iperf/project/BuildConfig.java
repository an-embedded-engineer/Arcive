/** Automatically generated file. DO NOT MODIFY */
package iperf.project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}