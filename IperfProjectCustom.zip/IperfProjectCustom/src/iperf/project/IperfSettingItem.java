/**
 * 
 */
package iperf.project;

/**
 * @author Shin
 *
 */
public class IperfSettingItem 
{
	private String name;
	private String value;
	
	public String getName()
	{
		return name;
	}
	
	public String getValue()
	{
		return value;
	}
	
	public IperfSettingItem(String name, String value)
	{
		this.name = name;
		this.value = value;
	}

	@Override
	public String toString() 
	{
		return String.format("%s = %s", this.name, this.value);
	}
	
	
	
}
