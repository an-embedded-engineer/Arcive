package iperf.project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import iperf.project.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

//Main class of the activity
public class IperfProjectCustom extends Activity {

	String tag = "IperfProjectCustom";
	
	//A global pointer for instances of iperf (only one at a time is allowed). 
	IperfTask iperfTaskServer = null;
	IperfTask iperfTaskClient = null;
		
	//This is a required method that implements the activity startup
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//Shows the logo screen, and waits for a tap to continue to the main screen
		setContentView(R.layout.iperf_activity);

		// Initialize View
		initView();
	}

	private void initView() {
		
		final Spinner spnrServer = (Spinner) findViewById(R.id.spnrServer);
		final Spinner spnrClient = (Spinner) findViewById(R.id.spnrClient);
		final EditText editorServer = (EditText) findViewById(R.id.editServerCommand);
		final EditText editorClient = (EditText) findViewById(R.id.editClientCommand);
		
		IperfSettingFileManager manager = new IperfSettingFileManager(this);
		
		InputStream in = manager.getStream();
		
		IperfSettingParser parser = new IperfSettingParser(in);
		
		final IperfSetting settingServer = parser.getSetting("Server");
		final IperfSetting settingClient = parser.getSetting("Client");
		
		Log.d(tag, String.format("%s", settingServer.toString()));
		Log.d(tag, String.format("%s", settingClient.toString()));
		
		initSpinner(spnrServer, editorServer, settingServer);
		
		initSpinner(spnrClient, editorClient, settingClient);

	}

	private void initSpinner(final Spinner spinner, final EditText editor, final IperfSetting setting) 
	{
		spinner.setAdapter(createAdapter(setting));
		
		spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			
			IperfSettingItem[] items = setting.getItems();

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				
				editor.setText(items[position].getValue());
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				editor.setText("");
			}
		});
	}
	
	public ArrayAdapter<String> createAdapter(IperfSetting setting)
	{
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		
		IperfSettingItem[] itemsServer = setting.getItems();
		for(int i=0; i < itemsServer.length; i++)
		{
			adapter.add(itemsServer[i].getName());
		}
		
		return adapter;
	}

	//This function is used to copy the iperf executable to a directory which execute permissions for this application, and then gives it execute permissions.
	//It runs on every initiation of an iperf test, but copies the file only if it's needed.
	public void initIperfServer() {
		final TextView tv = (TextView) findViewById(R.id.textServerLog);
		final ScrollView sv = (ScrollView) findViewById(R.id.scrollServer);
		final EditText et = (EditText) findViewById(R.id.editServerCommand);
		final ToggleButton tb = (ToggleButton) findViewById(R.id.toggleServer);
		
		InputStream in;
		try {
			//The asset "iperf" (from assets folder) inside the activity is opened for reading.
			in = getResources().getAssets().open("iperf");
		} catch (IOException e2) {
			tv.append("\nError occurred while accessing system resources, please reboot and try again.");
			return;			
		}
		try {
			//Checks if the file already exists, if not copies it.
			new FileInputStream("/data/data/iperf.project/iperf");
		} catch (FileNotFoundException e1) {
			try {
				//The file named "iperf" is created in a system designated folder for this application.
				OutputStream out = new FileOutputStream("/data/data/iperf.project/iperf", false); 
				// Transfer bytes from "in" to "out"
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
				//After the copy operation is finished, we give execute permissions to the "iperf" executable using shell commands.
				Process processChmod = Runtime.getRuntime().exec("/system/bin/chmod 744 /data/data/iperf.project/iperf"); 
				// Executes the command and waits until it finishes.
				processChmod.waitFor();
			} catch (IOException e) {
				tv.append("\nError occurred while accessing system resources, please reboot and try again.");
				return;
			} catch (InterruptedException e) {
				tv.append("\nError occurred while accessing system resources, please reboot and try again.");
				return;
			}		
			//Creates an instance of the class IperfTask for running an iperf test, then executes.
			iperfTaskServer = new IperfTask(tv, sv, et, tb);
			iperfTaskServer.execute();				
			return;					
		} 
		//Creates an instance of the class IperfTask for running an iperf test, then executes.
		iperfTaskServer = new IperfTask(tv, sv, et, tb);
		iperfTaskServer.execute();
		
		return;
	}

	//This method is used to handle toggle button clicks
	public void ToggleButtonServerClick(View v) {
		final ToggleButton toggleButton = (ToggleButton) findViewById(R.id.toggleServer);
		final EditText inputCommands = (EditText) findViewById(R.id.editServerCommand);
		//If the button is not pushed (waiting for starting a test), then a iperf task is started.
		if (toggleButton.isChecked()) {
			InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			mgr.hideSoftInputFromWindow(inputCommands.getWindowToken(), 0);
			initIperfServer();
			Log.i("iperf_server", "Iperf Server Started");
		//If a test is already running then a cancel command is issued through the iperfTask interface.
		} else {
			if (iperfTaskServer == null){
				toggleButton.setChecked(false);
				return;
			}
			iperfTaskServer.cancel(true);
			iperfTaskServer = null;
			Log.i("iperf_server", "Iperf Server Cancelled");
		}
	}

	//This method is used to handle the save button click
	public void SaveButtonServerClick(View v) {
		final TextView tv = (TextView) findViewById(R.id.textServerLog);
		
		//Create a dialog for filename input
		final AlertDialog.Builder alert = new AlertDialog.Builder(this);
		final EditText input = new EditText(this);
		input.setHint("Please enter a filename");
		alert.setView(input);
		alert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				String value = input.getText().toString().trim();
				try {
					//Save file on SD card
				    File sdroot = Environment.getExternalStorageDirectory();
				    if (sdroot.canWrite()){
				        File txtfile = new File(sdroot, (value + ".txt"));
				        FileWriter txtwriter = new FileWriter(txtfile);
				        BufferedWriter out = new BufferedWriter(txtwriter);
				        out.write(tv.getText().toString());
				        out.close();
						tv.append("\nLog file saved to SD card.");		 
				    }
				} catch (IOException e) {
					tv.append("\nError occurred while saving log file, please check the SD card.");		    
				}
			}
		});

		alert.setNegativeButton("Cancel",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						dialog.cancel();
					}
				});
		alert.show();
		

	}
	
	//This function is used to copy the iperf executable to a directory which execute permissions for this application, and then gives it execute permissions.
		//It runs on every initiation of an iperf test, but copies the file only if it's needed.
		public void initIperfClient() {
			final TextView tv = (TextView) findViewById(R.id.textClientLog);
			final ScrollView sv = (ScrollView) findViewById(R.id.scrollClient);
			final EditText et = (EditText) findViewById(R.id.editClientCommand);
			final ToggleButton tb = (ToggleButton) findViewById(R.id.toggleClient);
			
			InputStream in;
			try {
				//The asset "iperf" (from assets folder) inside the activity is opened for reading.
				in = getResources().getAssets().open("iperf");
			} catch (IOException e2) {
				tv.append("\nError occurred while accessing system resources, please reboot and try again.");
				return;			
			}
			try {
				//Checks if the file already exists, if not copies it.
				new FileInputStream("/data/data/iperf.project/iperf");
			} catch (FileNotFoundException e1) {
				try {
					//The file named "iperf" is created in a system designated folder for this application.
					OutputStream out = new FileOutputStream("/data/data/iperf.project/iperf", false); 
					// Transfer bytes from "in" to "out"
					byte[] buf = new byte[1024];
					int len;
					while ((len = in.read(buf)) > 0) {
						out.write(buf, 0, len);
					}
					in.close();
					out.close();
					//After the copy operation is finished, we give execute permissions to the "iperf" executable using shell commands.
					Process processChmod = Runtime.getRuntime().exec("/system/bin/chmod 744 /data/data/iperf.project/iperf"); 
					// Executes the command and waits until it finishes.
					processChmod.waitFor();
				} catch (IOException e) {
					tv.append("\nError occurred while accessing system resources, please reboot and try again.");
					return;
				} catch (InterruptedException e) {
					tv.append("\nError occurred while accessing system resources, please reboot and try again.");
					return;
				}		
				//Creates an instance of the class IperfTask for running an iperf test, then executes.
				iperfTaskClient = new IperfTask(tv, sv, et, tb);
				iperfTaskClient.execute();				
				return;					
			} 
			//Creates an instance of the class IperfTask for running an iperf test, then executes.
			iperfTaskClient = new IperfTask(tv, sv, et, tb);
			iperfTaskClient.execute();
			
			return;
		}

		//This method is used to handle toggle button clicks
		public void ToggleButtonClientClick(View v) {
			final ToggleButton toggleButton = (ToggleButton) findViewById(R.id.toggleClient);
			final EditText inputCommands = (EditText) findViewById(R.id.editClientCommand);
			//If the button is not pushed (waiting for starting a test), then a iperf task is started.
			if (toggleButton.isChecked()) {
				InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				mgr.hideSoftInputFromWindow(inputCommands.getWindowToken(), 0);
				initIperfClient();
				Log.i("iperf_client", "Iperf Client Started");
			//If a test is already running then a cancel command is issued through the iperfTask interface.
			} else {
				if (iperfTaskClient == null){
					toggleButton.setChecked(false);
					return;
				}
				iperfTaskClient.cancel(true);
				iperfTaskClient = null;
				Log.i("iperf_client", "Iperf Client Cancelled");
			}
		}

		//This method is used to handle the save button click
		public void SaveButtonClientClick(View v) {
			final TextView tv = (TextView) findViewById(R.id.textClientLog);
			
			//Create a dialog for filename input
			final AlertDialog.Builder alert = new AlertDialog.Builder(this);
			final EditText input = new EditText(this);
			input.setHint("Please enter a filename");
			alert.setView(input);
			alert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					String value = input.getText().toString().trim();
					try {
						//Save file on SD card
					    File sdroot = Environment.getExternalStorageDirectory();
					    if (sdroot.canWrite()){
					        File txtfile = new File(sdroot, (value + ".txt"));
					        FileWriter txtwriter = new FileWriter(txtfile);
					        BufferedWriter out = new BufferedWriter(txtwriter);
					        out.write(tv.getText().toString());
					        out.close();
							tv.append("\nLog file saved to SD card.");		 
					    }
					} catch (IOException e) {
						tv.append("\nError occurred while saving log file, please check the SD card.");		    
					}
				}
			});

			alert.setNegativeButton("Cancel",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int whichButton) {
							dialog.cancel();
						}
					});
			alert.show();

		}

	//The main class for executing iperf instances.
	//With every test started, an instance of this class is created, and is destroyed when the test is done.
	//This class extends the class AsyncTask which is used to perform long background tasks and allow updates to the GUI while running.
	//This is done by overriding certain functions that offer this functionality.
	class IperfTask extends AsyncTask<Void, String, String> {
		TextView tv;
		ScrollView scroller;
		EditText inputCommands;
		ToggleButton toggleButton;

		Process process = null;
		
		public IperfTask(TextView tv, ScrollView sv, EditText et, ToggleButton tb){
			this.tv = tv;
			this.scroller = sv;
			this.inputCommands = et;
			this.toggleButton = tb;
		}

		//This function is used to implement the main task that runs on the background.
		@Override
		protected String doInBackground(Void... voids) {
			//Iperf command syntax check using a Regular expression to protect the system from user exploitation.
			String str = inputCommands.getText().toString();
			if (!str.matches("(iperf )?((-[s,-server])|(-[c,-client] ([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5]))|(-[c,-client] \\w{1,63})|(-[h,-help]))(( -[f,-format] [bBkKmMgG])|(\\s)|( -[l,-len] \\d{1,5}[KM])|( -[B,-bind] \\w{1,63})|( -[r,-tradeoff])|( -[v,-version])|( -[N,-nodelay])|( -[T,-ttl] \\d{1,8})|( -[U,-single_udp])|( -[d,-dualtest])|( -[w,-window] \\d{1,5}[KM])|( -[n,-num] \\d{1,10}[KM])|( -[p,-port] \\d{1,5})|( -[L,-listenport] \\d{1,5})|( -[t,-time] \\d{1,8})|( -[i,-interval] \\d{1,4})|( -[u,-udp])|( -[b,-bandwidth] \\d{1,20}[bBkKmMgG])|( -[m,-print_mss])|( -[P,-parallel] d{1,2})|( -[M,-mss] d{1,20}))*"))
			{
				publishProgress("Error: invalid syntax. Please try again.\n\n");
				return null;
			}
			try {
				//The user input for the parameters is parsed into a string list as required from the ProcessBuilder Class.
				String[] commands = inputCommands.getText().toString().split(" ");
				List<String> commandList = new ArrayList<String>(Arrays.asList(commands));
				//If the first parameter is "iperf", it is removed
				if (commandList.get(0).equals((String)"iperf")) {
					commandList.remove(0);
				}
				//The execution command is added first in the list for the shell interface.
				commandList.add(0,"/data/data/iperf.project/iperf");
				//The process is now being run with the verified parameters.
				process = new ProcessBuilder().command(commandList).redirectErrorStream(true).start();
				//A buffered output of the stdout is being initialized so the iperf output could be displayed on the screen.
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				int read;
				//The output text is accumulated into a string buffer and published to the GUI
				char[] buffer = new char[4096];
				StringBuffer output = new StringBuffer();
				while ((read = reader.read(buffer)) > 0) {
					output.append(buffer, 0, read);
					//This is used to pass the output to the thread running the GUI, since this is separate thread.
					Log.i("iperf", output.toString());
					publishProgress(output.toString());
					output.delete(0, output.length());
				}
				reader.close();
				process.destroy();
			}
			catch (IOException e) {
				publishProgress("\nError occurred while accessing system resources, please reboot and try again.");
				e.printStackTrace();
			}
			return null;
		}

		//This function is called by AsyncTask when publishProgress is called.
		//This function runs on the main GUI thread so it can publish changes to it, while not getting in the way of the main task.
		@Override
		public void onProgressUpdate(String... strings) {
			tv.append(strings[0]);
			//The next command is used to roll the text to the bottom
			scroller.post(new Runnable() {
				public void run() {
					scroller.smoothScrollTo(0, tv.getBottom());
				}
			});
		}

		//This function is called by the AsyncTask class when IperfTask.cancel is called.
		//It is used to terminate an already running task.
		@Override
		public void onCancelled() {
			//The running process is destroyed and system resources are freed.
			if (process != null) {
				process.destroy();
				try {
					process.waitFor();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			//The toggle button is switched to "off"
			toggleButton.setChecked(false);
			tv.append("\nOperation aborted.\n\n");
			//The next command is used to roll the text to the bottom
			scroller.post(new Runnable() {
				public void run() {
					scroller.smoothScrollTo(0, tv.getBottom());
				}
			});
		}

		@Override
		public void onPostExecute(String result) {
			//The running process is destroyed and system resources are freed.
			if (process != null) {
				process.destroy();
			
				try {
					process.waitFor();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				tv.append("\nTest is done.\n\n");
			}
			//The toggle button is switched to "off"
			toggleButton.setChecked(false);
			//The next command is used to roll the text to the bottom
			scroller.post(new Runnable() {
				public void run() {
					scroller.smoothScrollTo(0, tv.getBottom());
				}
			});
		}
	}

}
