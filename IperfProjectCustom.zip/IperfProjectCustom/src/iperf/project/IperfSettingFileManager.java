package iperf.project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

public class IperfSettingFileManager {
	
	String tag = "IperfSettingFileManager";
	
	String fileName = "setting.xml";
	Context context = null;
	InputStream stream = null;
	
	File settingDir = null;
	File settingFile =null;
	
	public InputStream getStream()
	{
		return this.stream;
	}
	
	public IperfSettingFileManager(Context context)
	{
		this.context = context;
		settingDir = new File(Environment.getExternalStorageDirectory(), context.getPackageName());
		settingFile = new File(settingDir.toString(), fileName);
		
		Log.d(tag, String.format("Setting File : %s", settingFile.toString()));
		
		if(settingDir.exists() == false)
		{	
			loadFromAssets();
			
			settingDir.mkdir();
			
			saveToSdCard();
			
			loadFromSdCard();
		}
		else
		{
			if(settingFile.exists() == false)
			{
				loadFromAssets();
				
				saveToSdCard();
				
				loadFromSdCard();
			}
			else
			{
				loadFromSdCard();
			}
		}
		
		
	}

	private void saveToSdCard() 
	{
		
		String line;
		StringBuilder builder = new StringBuilder();
		
		try 
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(stream));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(settingFile, false), "UTF-8"));
			
			while((line = br.readLine())!= null)
			{
				builder.append(line);
				builder.append("\n");
			}
			
			bw.write(builder.toString());
			
			br.close();
			bw.close();
			
		} catch (Exception e) {
			// TODO �����������ꂽ catch �u���b�N
			e.printStackTrace();
		}		
		
	}
	
	public InputStream loadFromAssets()
	{
		try 
		{
			this.stream = context.getResources().getAssets().open("setting.xml");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return this.stream;
	}
	
	public InputStream loadFromSdCard()
	{
		try
		{
			FileInputStream fis = new FileInputStream(settingFile);
			
			stream = fis;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return stream;
	}

}
