/**
 * 
 */
package iperf.project;

import java.util.LinkedList;

/**
 * @author Shin
 *
 */
public class IperfSetting 
{
	
	public enum SettingType
	{
		TYPE_SERVER,
		TYPE_CLIENT,
		TYPE_COUNT,
	}
	
	SettingType type;
	LinkedList<IperfSettingItem> itemList = new LinkedList<IperfSettingItem>();
	
	public SettingType getType()
	{
		return type;
	}
	
	public IperfSettingItem[] getItems()
	{
		IperfSettingItem[] items = new IperfSettingItem[itemList.size()];
		
		itemList.toArray(items);
		
		return items;
	}
	
	public IperfSetting(SettingType type)
	{
		this.type = type;
	}
	
	public void ApeendItem(IperfSettingItem item)
	{
		itemList.add(item);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		builder.append(String.format("Iperf Command type = %s\n", this.type.toString()));
		for(int i = 0; i < itemList.size(); i++)
		{
			String name = itemList.get(i).getName();
			String value = itemList.get(i).getValue();
			builder.append(String.format("  Command %d : %s = %s\n", i+1, name, value));
		}
		
		return builder.toString();
	}
	
	
}
