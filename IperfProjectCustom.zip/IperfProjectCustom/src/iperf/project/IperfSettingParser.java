/**
 * 
 */
package iperf.project;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.util.Log;
import android.util.Xml;

/**
 * @author Shin
 *
 */
public class IperfSettingParser {
	
	String tag = "IperfSettingParser";
	XmlPullParser parser = null;
	
	HashMap<String, IperfSetting> map = new HashMap<String, IperfSetting>();
	
	public IperfSetting getSetting(String key)
	{		
		return map.get(key);
	}
	
	IperfSettingParser(InputStream in)
	{
		parser = Xml.newPullParser();
		
		parse(in);
	}

	private void parse(InputStream in) {
		
		IperfSetting setting = null;
		String commandType = null;
		String commandName = null;
		
		try {
			parser.setInput(in, "UTF-8");
			
			for(int eventType = parser.getEventType(); eventType != XmlPullParser.END_DOCUMENT; eventType = parser.next())
			{
				switch(eventType)
				{
				case XmlPullParser.START_TAG:
					String startTag = parser.getName();
					Log.d(tag, String.format("Start <%s>", startTag));
					if(startTag.equals("command"))
					{
						if(parser.getAttributeCount() >= 1)
						{
							String attr = parser.getAttributeValue(0);
							commandType = attr;
							if(attr.equals("Server"))
							{
								setting = new IperfSetting(IperfSetting.SettingType.TYPE_SERVER);
								Log.d(tag, String.format("Setting [%s] is created", attr));
							}
							else if(attr.equals("Client"))
							{
								setting = new IperfSetting(IperfSetting.SettingType.TYPE_CLIENT);
								Log.d(tag, String.format("Setting [%s] is created", attr));
							}
							else
							{
								Log.e(tag, String.format("Unknown Command Type : %s", attr));
							}
						}
						else
						{
							Log.e(tag, String.format("Type is not specified"));
						}
					}
					else if(startTag.equals("item"))
					{
						if(parser.getAttributeCount() >= 1)
						{
							String attr = parser.getAttributeValue(0);
							commandName = attr;
						}
						else
						{
							Log.e(tag, String.format("Command name is not specified"));
						}
					}
					break;
				case XmlPullParser.TEXT:
					String text = parser.getText();
					
					if(text.trim().length() != 0)
					{
						IperfSettingItem item = new IperfSettingItem(commandName, text);								
						setting.ApeendItem(item);
						
						Log.d(tag, String.format("Add Item : %s = [%s]", commandName, text));
					}
					break;
				case XmlPullParser.END_TAG:
					String endTag = parser.getName();
					Log.d(tag, String.format("End <%s>", endTag));
					if(endTag.equals("command"))
					{
						map.put(commandType, setting);
						Log.d(tag, String.format("Add HasMap : %s = [%s]", commandType, setting.getType().toString()));
					}
					break;
				}
			}
			
		} catch (XmlPullParserException e) {
			// TODO �����������ꂽ catch �u���b�N
			e.printStackTrace();
		} catch (IOException e) {
			// TODO �����������ꂽ catch �u���b�N
			e.printStackTrace();
		}
	}

}
