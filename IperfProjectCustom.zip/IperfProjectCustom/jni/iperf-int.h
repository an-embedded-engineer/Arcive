#ifndef _IPERF_INCLUDE_IPERF_INT_H
#define _IPERF_INCLUDE_IPERF_INT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "iperf 2.0.4"
/* generated using gnu compiler gcc (Ubuntu 4.3.2-1ubuntu12) 4.3.2 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
