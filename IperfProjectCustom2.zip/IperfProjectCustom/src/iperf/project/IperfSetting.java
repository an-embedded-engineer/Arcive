/**
 * 
 */
package iperf.project;

import java.util.LinkedList;

// IperfSetting Class
public class IperfSetting
{
    // �ݒ�^�C�v
    public enum SettingType
    {
        TYPE_SERVER, TYPE_CLIENT, TYPE_COUNT,
    }

    SettingType type;
    LinkedList<IperfSettingItem> itemList = new LinkedList<IperfSettingItem>();

    // �ݒ�^�C�v���擾
    public SettingType getType()
    {
        return type;
    }

    // �ݒ荀�ڂ��擾
    public IperfSettingItem[] getItems()
    {
        IperfSettingItem[] items = new IperfSettingItem[itemList.size()];

        itemList.toArray(items);

        return items;
    }

    // �R���X�g���N�^
    public IperfSetting(SettingType type)
    {
        this.type = type;
    }

    // �ݒ荀�ڂ�ǉ�
    public void apeendItem(IperfSettingItem item)
    {
        itemList.add(item);
    }
    
    // �ݒ荀�ڂ��폜
    public void removeItemAt(int index)
    {
        itemList.remove(index);
    }
    
    // �ݒ荀�ڂ��폜
    public void removeItem(IperfSettingItem item)
    {
        itemList.remove(item);
    }
    
    // �ݒ荀�ڂ�ҏW
    public void modifyItem(int index, IperfSettingItem item)
    {
        itemList.set(index, item);
    }

    // ������ɕϊ�
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();

        builder.append(String.format("Iperf Command type = %s\n", this.type.toString()));
        for (int i = 0; i < itemList.size(); i++)
        {
            String name = itemList.get(i).getName();
            String value = itemList.get(i).getValue();
            builder.append(String.format("  Command %d : %s = %s\n", i + 1, name, value));
        }

        return builder.toString();
    }

}
