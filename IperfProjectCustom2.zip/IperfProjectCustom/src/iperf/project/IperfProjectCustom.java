package iperf.project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import iperf.project.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

// Main Activity
public class IperfProjectCustom extends Activity
{

    String tag = "IperfProjectCustom";

    // iperf���s�p�^�X�N
    IperfTask iperfTaskServer = null;
    IperfTask iperfTaskClient = null;
    String binFilePath = "/data/data/iperf.project/iperf";
    File binFile = new File(binFilePath);

    // onCreate Event
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iperf_activity);

        Log.d(tag, String.format("OnCreate Event Occured"));
        // View��������
        initView();
    }
    
    // onResume Event
    @Override
    protected void onResume()
    {
        super.onResume();
        
        Log.d(tag, String.format("OnResume Event Occured"));
        
        // View�����Z�b�g
        initView();
    }
    
    // onRestart Event
    @Override
    protected void onRestart()
    {
        super.onRestart();
        
        Log.d(tag, String.format("OnRestart Event Occured"));
        
        // View�����Z�b�g
        initView();
    }

    // onCreateOptionsMenu Event
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Menu List���擾
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    
    // onOptionsItemSelected Event
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Log.d("test", String.format("ID : %d",item.getItemId()));
        
        // ID�ɂ���Ĕ���
        switch(item.getItemId())
        {
            // Setting Menu
            case R.id.menu_settings:
                Log.d("test", String.format("Setting Start"));
                // SettingListActivity���Ăяo��
                Intent i = new Intent(getApplicationContext(), SettingListActivity.class);
                startActivity(i);
                break;
            default :
                break;
        }
        return true;
    }

    // View��������
    private void initView()
    {
        final Spinner spnrServer = (Spinner) findViewById(R.id.spnrServer);
        final Spinner spnrClient = (Spinner) findViewById(R.id.spnrClient);
        final EditText editorServer = (EditText) findViewById(R.id.editServerCommand);
        final EditText editorClient = (EditText) findViewById(R.id.editClientCommand);

        // �ݒ�t�@�C����ǂݍ���
        IperfSettingManager settingManager = IperfSettingManager.getInstance(this);

        // Server / Client�p�ݒ���擾
        final IperfSetting settingServer = settingManager.getSetting("Server");
        final IperfSetting settingClient = settingManager.getSetting("Client");

        Log.d(tag, String.format("%s", settingServer.toString()));
        Log.d(tag, String.format("%s", settingClient.toString()));

        // Server / Client�ݒ肩��Spinner��������
        initSpinner(spnrServer, editorServer, settingServer);
        initSpinner(spnrClient, editorClient, settingClient);        
    }

    // Spinner��������
    private void initSpinner(final Spinner spinner, final EditText editor, final IperfSetting setting)
    {
        // Spinner�pAdapter��ݒ肩��ǂݍ��݁A�Z�b�g
        spinner.setAdapter(createAdapter(setting));

        // Spinner�@Selected Listener��o�^
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            // �ݒ荀�ڃ��X�g���擾
            IperfSettingItem[] items = setting.getItems();

            // Item Selected Event
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                // �ݒ�l��EditText�ɃZ�b�g
                editor.setText(items[position].getValue());
            }

            // Nothing Selected Event
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // EditText���N���A
                editor.setText("");
            }
        });
    }

    // �ݒ肩��ArrayAdapter�𐶐�
    public ArrayAdapter<String> createAdapter(IperfSetting setting)
    {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // �ݒ荀�ڃ��X�g���擾
        IperfSettingItem[] items = setting.getItems();
        for (int i = 0; i < items.length; i++)
        {
            // Adapter�ɍ��ږ���ǉ�
            adapter.add(items[i].getName());
        }

        return adapter;
    }

    // iperf����ƃf�B���N�g���ɃR�s�[
    private void copyIperf(InputStream in) throws IOException, InterruptedException
    {
        // �t�@�C���o�̓X�g���[�����擾
        OutputStream out = new FileOutputStream(binFilePath, false);

        // ���̓X�g���[������o�̓X�g���[���Ƀf�[�^���R�s�[
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0)
        {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();

        // �p�[�~�b�V������ύX
        Process processChmod = Runtime.getRuntime().exec("/system/bin/chmod 744 " + binFilePath);
        processChmod.waitFor();

    }

    // iperf(Server)�����������Ĕ񓯊��^�X�N�Ŏ��s
    public void initIperfServer()
    {
        final TextView tv = (TextView) findViewById(R.id.textServerLog);
        final ScrollView sv = (ScrollView) findViewById(R.id.scrollServer);
        final EditText et = (EditText) findViewById(R.id.editServerCommand);
        final ToggleButton tb = (ToggleButton) findViewById(R.id.toggleServer);

        // iperf�����݂��Ă��Ȃ�
        if (binFile.exists() == false)
        {
            try
            {
                // Assets����t�@�C����ǂݍ���
                InputStream in = getResources().getAssets().open("iperf");

                // ��ƃf�B���N�g����iperf���R�s�[
                copyIperf(in);
            }
            catch (Exception e)
            {
                tv.append("\nError occurred while accessing system resources, please reboot and try again.");
                Log.e(tag, String.format("Resource Access Error."), e);
                return;
            }
        }

        // iperf���s�p�񓯊��^�X�N�𐶐����A���s
        iperfTaskServer = new IperfTask(tv, sv, et, tb);
        iperfTaskServer.execute();

        return;
    }

    // iperf(Client)�����������Ĕ񓯊��^�X�N�Ŏ��s
    public void initIperfClient()
    {
        final TextView tv = (TextView) findViewById(R.id.textClientLog);
        final ScrollView sv = (ScrollView) findViewById(R.id.scrollClient);
        final EditText et = (EditText) findViewById(R.id.editClientCommand);
        final ToggleButton tb = (ToggleButton) findViewById(R.id.toggleClient);

        // iperf�����݂��Ă��Ȃ�
        if (binFile.exists() == false)
        {
            try
            {
                // Assets����t�@�C����ǂݍ���
                InputStream in = getResources().getAssets().open("iperf");

                // ��ƃf�B���N�g����iperf���R�s�[
                copyIperf(in);
            }
            catch (Exception e)
            {
                tv.append("\nError occurred while accessing system resources, please reboot and try again.");
                Log.e(tag, String.format("Resource Access Error."), e);
                return;
            }
        }

        // iperf���s�p�񓯊��^�X�N�𐶐����A���s
        iperfTaskClient = new IperfTask(tv, sv, et, tb);
        iperfTaskClient.execute();

        return;
    }

    // Toggle Button(Server) Click Event
    public void ToggleButtonServerClick(View v)
    {
        final ToggleButton toggleButton = (ToggleButton) findViewById(R.id.toggleServer);
        final EditText inputCommands = (EditText) findViewById(R.id.editServerCommand);
        
        // Toggle = ON
        if (toggleButton.isChecked())
        {
            // �\�t�g�L�[�{�[�h���B��
            InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            mgr.hideSoftInputFromWindow(inputCommands.getWindowToken(), 0);
            
            // iperf(Server)�����������Ď��s
            initIperfServer();
            Log.i(tag, "Iperf Server Started");
        }
        // Toggle = OFF
        else
        {
            // �^�X�N����������Ă��Ȃ�
            if (iperfTaskServer == null)
            {
                toggleButton.setChecked(false);
                return;
            }
            
            // �񓯊��^�X�N���~
            // **** cancel()����onCanceled()���Ă΂�Ȃ����߁A���ڌďo�� ****
            //iperfTaskServer.cancel(true);
            iperfTaskServer.onCancelled();
            iperfTaskServer = null;
            Log.i(tag, "Iperf Server Cancelled");
        }
    }

    // Toggle Button(Client) Click Event
    public void ToggleButtonClientClick(View v)
    {
        final ToggleButton toggleButton = (ToggleButton) findViewById(R.id.toggleClient);
        final EditText inputCommands = (EditText) findViewById(R.id.editClientCommand);
        
        // Toggle = ON
        if (toggleButton.isChecked())
        {
            // �\�t�g�L�[�{�[�h���B��
            InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            mgr.hideSoftInputFromWindow(inputCommands.getWindowToken(), 0);
            
            // iperf(Client)�����������Ď��s
            initIperfClient();
            Log.i(tag, "Iperf Client Started");
        }
        // Toggle = ON
        else
        {
            // �^�X�N����������Ă��Ȃ�
            if (iperfTaskServer == null)
            {
                toggleButton.setChecked(false);
                return;
            }
            
            // �񓯊��^�X�N���~
            // **** cancel()����onCanceled()���Ă΂�Ȃ����߁A���ڌďo�� ****
            //iperfTaskClient.cancel(true);
            iperfTaskClient.onCancelled();
            iperfTaskClient = null;
            Log.i(tag, "Iperf Client Cancelled");
        }
    }

    // Log�t�@�C����SD Card�ɕۑ�
    private void saveLogFile(final TextView tv)
    {
        // �t�@�C�������̓_�C�A���O��\��
        final AlertDialog.Builder alert = new AlertDialog.Builder(this);
        final EditText input = new EditText(this);
        input.setHint("Please enter a filename");
        alert.setView(input);
        
        alert.setPositiveButton("Save", new DialogInterface.OnClickListener()
        {
            // PositiveButton Click Event
            public void onClick(DialogInterface dialog, int whichButton)
            {
                // ���͂��ꂽ�t�@�C�������擾
                String value = input.getText().toString().trim();
                try
                {
                    // SD Card�Ƀt�@�C����ۑ�
                    File sdroot = Environment.getExternalStorageDirectory();
                    if (sdroot.canWrite())
                    {
                        File txtfile = new File(sdroot, (value + ".txt"));
                        FileWriter txtwriter = new FileWriter(txtfile);
                        BufferedWriter out = new BufferedWriter(txtwriter);
                        out.write(tv.getText().toString());
                        out.close();
                        tv.append("\nLog file saved to SD card.");
                    }
                }
                catch (Exception e)
                {
                    tv.append("\nError occurred while saving log file, please check the SD card.");
                    Log.e(tag, "Save Log file failed", e);
                }
            }
        });

        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
        {
            // NegativeButton Click Event
            public void onClick(DialogInterface dialog, int whichButton)
            {
                // ������L�����Z��
                dialog.cancel();
            }
        });
        alert.show();
    }

    // Save�@Button(Server) Click Event
    public void SaveButtonServerClick(View v)
    {
        final TextView tv = (TextView) findViewById(R.id.textServerLog);

        // ���O�t�@�C���ɕۑ�
        saveLogFile(tv);
    }

    // Save�@Button(Client) Click Event
    public void SaveButtonClientClick(View v)
    {
        final TextView tv = (TextView) findViewById(R.id.textClientLog);

        // ���O�t�@�C���ɕۑ�
        saveLogFile(tv);

    }

    // iperf���s�p�񓯊��^�X�N
    class IperfTask extends AsyncTask<Void, String, String>
    {
        TextView tv;
        ScrollView scroller;
        EditText inputCommands;
        ToggleButton toggleButton;

        Process process = null;

        // �R���X�g���N�^
        public IperfTask(TextView tv, ScrollView sv, EditText et, ToggleButton tb)
        {
            this.tv = tv;
            this.scroller = sv;
            this.inputCommands = et;
            this.toggleButton = tb;
        }

        // �o�b�N�O���E���h���s
        @Override
        protected String doInBackground(Void... voids)
        {
            // ���̓R�}���h�̍\���`�F�b�N
            String str = inputCommands.getText().toString();
            if (!str.matches("(iperf )?((-[s,-server])|(-[c,-client] ([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5]))|(-[c,-client] \\w{1,63})|(-[h,-help]))(( -[f,-format] [bBkKmMgG])|(\\s)|( -[l,-len] \\d{1,5}[KM])|( -[B,-bind] \\w{1,63})|( -[r,-tradeoff])|( -[v,-version])|( -[N,-nodelay])|( -[T,-ttl] \\d{1,8})|( -[U,-single_udp])|( -[d,-dualtest])|( -[w,-window] \\d{1,5}[KM])|( -[n,-num] \\d{1,10}[KM])|( -[p,-port] \\d{1,5})|( -[L,-listenport] \\d{1,5})|( -[t,-time] \\d{1,8})|( -[i,-interval] \\d{1,4})|( -[u,-udp])|( -[b,-bandwidth] \\d{1,20}[bBkKmMgG])|( -[m,-print_mss])|( -[P,-parallel] d{1,2})|( -[M,-mss] d{1,20}))*"))
            {
                publishProgress("Error: invalid syntax. Please try again.\n\n");
                return null;
            }
            
            try
            {
                // ���̓R�}���h���擾
                String[] commands = inputCommands.getText().toString().split(" ");
                List<String> commandList = new ArrayList<String>(Arrays.asList(commands));
                
                // 1�Ԗڂ̈�����iperf
                if (commandList.get(0).equals((String) "iperf"))
                {
                    // �폜
                    commandList.remove(0);
                }
                
                // 1�Ԗڂ̈�����iperf�̎��s�p�X���i�[
                commandList.add(0, binFilePath);
                
                // Process�𐶐������s
                process = new ProcessBuilder().command(commandList).redirectErrorStream(true).start();
                
                // �W�����͂�BufferedReader�Ƀ��_�C���N�g
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                int read;
                
                // iperf����̏o�͕������UI Thread�ɑ��M
                char[] buffer = new char[4096];
                StringBuffer output = new StringBuffer();
                while ((read = reader.read(buffer)) > 0)
                {
                    output.append(buffer, 0, read);
                    // UI Thread�ɍX�V��ʒm
                    publishProgress(output.toString());
                    output.delete(0, output.length());
                }
                reader.close();
                // Process���~
                process.destroy();
            }
            catch (IOException e)
            {
                publishProgress("\nError occurred while accessing system resources, please reboot and try again.");
                e.printStackTrace();
                Log.e(tag, "iperf execute error", e);
            }
            return null;
        }

        // Progress�@Update Event
        @Override
        public void onProgressUpdate(String... strings)
        {
            // iperf����̏o�͕������TextView�ɏo��
            tv.append(strings[0]);
            // ���[�܂ŃX�N���[��
            scroller.post(new Runnable()
            {
                public void run()
                {
                    scroller.smoothScrollTo(0, tv.getBottom());
                }
            });
        }

        // Process Cancelled Event
        @Override
        public void onCancelled()
        {
            // Process���~���A���\�[�X�����
            if (process != null)
            {
                process.destroy();
                try
                {
                    process.waitFor();
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }
            
            // Toggle = OFF
            toggleButton.setChecked(false);
            tv.append("\nOperation aborted.\n\n");
            
            // ���[�܂ŃX�N���[��
            scroller.post(new Runnable()
            {
                public void run()
                {
                    scroller.smoothScrollTo(0, tv.getBottom());
                }
            });
        }

        // Post Execute Event
        @Override
        public void onPostExecute(String result)
        {
            // Process���~���A���\�[�X�����
            if (process != null)
            {
                process.destroy();

                try
                {
                    process.waitFor();
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                tv.append("\nTest is done.\n\n");
            }
            // Toggle = OFF
            toggleButton.setChecked(false);
            
            // ���[�܂ŃX�N���[��
            scroller.post(new Runnable()
            {
                public void run()
                {
                    scroller.smoothScrollTo(0, tv.getBottom());
                }
            });
        }
    }

}
