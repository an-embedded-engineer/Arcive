package iperf.project;

import java.util.ArrayList;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

public class SettingListActivity extends ListActivity
{
    String tag = "SettingListActivity";
    IperfSettingManager settingManager = null;
    Spinner spinner = null;
    Button btnAdd = null;
    Button btnDel = null;
    
    // onCreate Event
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_list);
        
        // �ݒ�̓ǂݍ���
        settingManager = IperfSettingManager.getInstance(this);
        
        // Spinner�̏�����
        initSpinner();
        // Add Button�̏�����
        initAddButton();
        // Delete Button�̏�����
        initDelButton();
        // ListView�̏�����
        initListView();
    }

    // ListView�̏�����
    private void initListView()
    {
        // FastScroll��L����
        this.getListView().setFastScrollEnabled(true);
        // Focus�֎~
        this.getListView().setItemsCanFocus(false);
        // Multiple �I�����[�h
        this.getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        // ItemLongClick Listener => Item�̕ҏW
        this.getListView().setOnItemLongClickListener(new OnItemLongClickListener()
        {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
            {
                // �ݒ�^�C�v���擾
                final String type = (String)spinner.getSelectedItem();
                final int index = position;
                // �ݒ�^�C�v����ݒ���擾
                final IperfSetting setting = settingManager.getSetting(type);
                IperfSettingItem item = setting.getItems()[index];
                
                // �ݒ�ҏW�_�C�A���O��\��
                AlertDialog.Builder alert = new AlertDialog.Builder(SettingListActivity.this);
                LayoutInflater inflater = LayoutInflater.from(SettingListActivity.this);
                View layout = inflater.inflate(R.layout.item_add, (ViewGroup)findViewById(R.id.layout_root));
                final EditText inputName = (EditText)layout.findViewById(R.id.inputName);
                final EditText inputCommand = (EditText)layout.findViewById(R.id.inputCommand);
                // ���݂̒l�����
                inputName.setText(item.getName());
                inputCommand.setText(item.getValue());
                
                alert.setTitle("Edit Command");
                alert.setView(layout);
                
                //�@OK Button Click Listener => �ҏW�m��
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    // PositiveButton Click Event
                    public void onClick(DialogInterface dialog, int whichButton)
                    {
                        // ���͒l����ݒ荀�ڂ𐶐�
                        IperfSettingItem item = new IperfSettingItem(inputName.getText().toString(), inputCommand.getText().toString());

                        // �ݒ荀�ڂ�u������
                        settingManager.modifySettingItem(type, index, item);
                        
                        // Adapter��Item�ꗗ��o�^
                        SettingListViewAdapter adapter = new SettingListViewAdapter(SettingListActivity.this, setting.getItems());
                        setListAdapter(adapter);
                    }
                });

                //�@Cancel Button Click Listener => �ҏW���~
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    // NegativeButton Click Event
                    public void onClick(DialogInterface dialog, int whichButton)
                    {
                        // ������L�����Z��
                        dialog.cancel();
                    }
                });
                // �ݒ�ҏW�_�C�A���O��\��
                alert.show();
                
                return true;
            }
        });
    }

    // Delete Button��������
    private void initDelButton()
    {
        btnDel = (Button)findViewById(R.id.btnDelete);
        
        // Delete Button Click Listener => �I�����ꂽItem���폜
        btnDel.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // �ݒ�^�C�v���擾
                String type = (String)spinner.getSelectedItem();
                // �ݒ�^�C�v����ݒ���擾
                final IperfSetting setting = settingManager.getSetting(type);
                IperfSettingItem[] items = setting.getItems();
                // �I�����ꂽItem��index���擾
                Integer[] indices = getSelectedIndices(items);
                // �폜�Ώۂ�Item�C���X�^���X�ꗗ���擾
                ArrayList<IperfSettingItem> removeItems = new ArrayList<IperfSettingItem>();
                for(Integer index : indices)
                {
                    removeItems.add(items[(int)index]);
                }
                
                // �폜�Ώ�Item��ݒ肩��폜
                for(IperfSettingItem item : removeItems)
                {
                    settingManager.removeSettingItem(type, item);
                }
                
                // Adapter��Item�ꗗ��o�^
                SettingListViewAdapter adapter = new SettingListViewAdapter(SettingListActivity.this, setting.getItems());
                setListAdapter(adapter);
            }
        });
    }
    
    // �I�����ꂽItem��index�ꗗ���擾
    private Integer[] getSelectedIndices(IperfSettingItem[] items)
    {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        SparseBooleanArray pos = getListView().getCheckedItemPositions();
        for(int i = 0; i < items.length; i++)
        {
            if(pos.valueAt(i))
            {
                indices.add(pos.keyAt(i));
            }
        }
        
        Integer[] array = new Integer[indices.size()];
        return indices.toArray(array);
    }

    // Add Button�̏�����
    private void initAddButton()
    {
        btnAdd = (Button)findViewById(R.id.btnAdd);
        // Add Button Click Listnenr => ���ڒǉ��_�C�A���O��\��
        btnAdd.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // ���ڒǉ��_�C�A���O��\��
                Context context = SettingListActivity.this;
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                LayoutInflater inflater = LayoutInflater.from(context);
                View layout = inflater.inflate(R.layout.item_add, (ViewGroup)findViewById(R.id.layout_root));
                final EditText inputName = (EditText)layout.findViewById(R.id.inputName);
                final EditText inputCommand = (EditText)layout.findViewById(R.id.inputCommand);
                
                alert.setTitle("Add New Command");
                alert.setView(layout);
                
                // OK Button Click Listener => �V�K���ڂ�ǉ�
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int whichButton)
                    {
                        // �ݒ�^�C�v���擾
                        String type = (String)spinner.getSelectedItem();
                        // ���͓��e����V�K���ڂ𐶐�
                        IperfSettingItem item = new IperfSettingItem(inputName.getText().toString(), inputCommand.getText().toString());                       
                        // �V�K���ڂ�ݒ�ɒǉ�
                        settingManager.appendSettingItem(type, item);
                        
                        // �ݒ�^�C�v����ݒ���擾
                        IperfSetting setting = settingManager.getSetting(type);
                        // Adapter��Item�ꗗ��o�^
                        SettingListViewAdapter adapter = new SettingListViewAdapter(SettingListActivity.this, setting.getItems());
                        setListAdapter(adapter);
                    }
                });

                // Cancel Button Click Listener => �V�K���ڒǉ����~
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    // NegativeButton Click Event
                    public void onClick(DialogInterface dialog, int whichButton)
                    {
                        // ������L�����Z��
                        dialog.cancel();
                    }
                });
                alert.show();
            }
        });
        
    }

    // Spinner��������
    private void initSpinner()
    {
        spinner = (Spinner)findViewById(R.id.spinnerType);
        // Adapter�̐ݒ�
        ArrayAdapter<String> adapterSpinner = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        
        // Adapter�ɐݒ�^�C�v��ǉ�
        for(String type : settingManager.getSettingTypes())
        {
            adapterSpinner.add(type);
        }
        
        // Spinner Item Selected Listener => List���X�V
        spinner.setOnItemSelectedListener(new OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                // �I������Ă���ݒ�^�C�v���擾
                String type = (String)spinner.getItemAtPosition(position);
                // �ݒ�^�C�v����ݒ���擾
                IperfSetting setting = settingManager.getSetting(type);
                
                // Adapter��Item�ꗗ��o�^
                SettingListViewAdapter adapter = new SettingListViewAdapter(SettingListActivity.this, setting.getItems());
                setListAdapter(adapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                /* Nothing to do. */                
            }
        });
        
        // Adapter��ݒ�
        spinner.setAdapter(adapterSpinner);
        
    }
}
