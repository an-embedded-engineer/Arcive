package iperf.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.LinearLayout;
import android.widget.ListView;

// CheckedDoubleTextView Class
public class CheckedDoubleTextView extends LinearLayout implements Checkable
{
    // �`�F�b�N�{�b�N�X
    private CheckBox chk;

    // �R���X�g���N�^
    public CheckedDoubleTextView(Context context)
    {
        super(context);
        Initialize(context);
    }
    
    // ������
    private void Initialize(Context context)
    {
        // Layout�@= LinearLayout
        this.setLayoutParams(new ListView.LayoutParams(ListView.LayoutParams.FILL_PARENT, ListView.LayoutParams.WRAP_CONTENT));
        // List Layout��ǂݍ���
        View view = ((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.list_layout, this, false);
        // CheckBox Widget���擾
        chk = (CheckBox)view.findViewById(R.id.check);
        
        // View��ݒ�
        this.addView(view);
    }

    // Check��Ԃ��擾
    @Override
    public boolean isChecked()
    {
        return chk.isChecked();
    }

    // Check��Ԃ��Z�b�g
    @Override
    public void setChecked(boolean checked)
    {
        chk.setChecked(checked);
    }

    // Check��Ԃ𔽓]
    @Override
    public void toggle()
    {
        chk.setChecked(!chk.isChecked());
    }

}
