/**
 * 
 */
package iperf.project;

// IperfSettingItem Class
public class IperfSettingItem
{
    private String name;
    private String value;

    // �ݒ薼���擾
    public String getName()
    {
        return name;
    }

    // �ݒ�l���擾
    public String getValue()
    {
        return value;
    }

    // �R���X�g���N�^
    public IperfSettingItem(String name, String value)
    {
        this.name = name;
        this.value = value;
    }

    // ������ɕϊ�
    @Override
    public String toString()
    {
        return String.format("%s = %s", this.name, this.value);
    }

}
