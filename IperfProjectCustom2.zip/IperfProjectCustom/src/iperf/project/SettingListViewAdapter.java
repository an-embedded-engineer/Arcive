package iperf.project;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

// SettingListViewAdapter Class
public class SettingListViewAdapter extends BaseAdapter
{
    IperfSettingItem[] items;
    Activity context;
    
    // �R���X�g���N�^
    public SettingListViewAdapter(Activity context, IperfSettingItem[] items)
    {
        this.context = context;
        this.items = items;
    }
    
    // �v�f�����擾
    @Override
    public int getCount()
    {
        return items.length;
    }

    // Item���擾
    @Override
    public Object getItem(int position)
    {
        return items[position];
    }

    // Item index���擾
    @Override
    public long getItemId(int position)
    {
        return position;
    }

    // View���擾
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        View view = convertView;
        ViewHolder holder;
        
        // View��������
        if(view == null)
        {
            // CheckBox�t����i�e�L�X�g���X�g
            view = new CheckedDoubleTextView(context);
            // ViewHolder�𐶐�
            holder = new ViewHolder(view);
            
            // Holder��ۑ�
            view.setTag(holder);
        }
        
        // Holder���擾
        holder = (ViewHolder)view.getTag();
        // Item��Bind
        holder.Bind(items[position]);

        return view;
    }
    
    // ViewHolder Class
    private class ViewHolder
    {
        TextView title;
        TextView text;
        
        // �R���X�g���N�^
        public ViewHolder(View view)
        {
            // View Widget���擾
            title = (TextView)view.findViewById(R.id.Text1);
            text = (TextView)view.findViewById(R.id.Text2);
        }
        
        // �ݒ荀�ڂ�Bind
        public void Bind(IperfSettingItem item)
        {
            if(item != null)
            {
                title.setText(item.getName());
                text.setText(item.getValue());
            }
        }
    }

}
