package iperf.project;

import java.util.HashMap;

import android.util.Log;

// IperfSettingCreator Class
public class IperfSettingCreator
{
    String tag = "IperfSettingCreator";
    HashMap<String, IperfSetting> settings = new HashMap<String, IperfSetting>();
    
    String XmlHeader = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
    String SettingStartTag = "<setting>\n";
    String SettingEndTag = "</setting>\n";
    
    String xmlDoc = null;
    
    // XML Document���擾
    public String getXmlDoc()
    {
        return xmlDoc;
    }
    
    // �R���X�g���N�^
    public IperfSettingCreator(HashMap<String, IperfSetting> settings)
    {
        this.settings = settings;
        
        // XML Document�𐶐�
        CreateXmlDoc();
    }

    // XML Document�𐶐�
    private void CreateXmlDoc()
    {
        StringBuilder builder = new StringBuilder();
        
        // Header��
        builder.append(XmlHeader);
        // <setting>
        builder.append(SettingStartTag);
        
        for(String type : settings.keySet())
        {
            Log.d(tag, String.format("type : %s", type));
            // <command type =[type]>
            builder.append(String.format("<command type=\"%s\">\n", type));
            
            for(IperfSettingItem item : settings.get(type).getItems())
            {
                // <item name=[name]>[value]</item>
                builder.append(String.format("<item name=\"%s\">%s</item>\n", item.getName(), item.getValue()));  
                Log.d(tag, String.format("Item : %s = %s", item.getName(), item.getValue()));
            }
            // </command>
            builder.append(String.format("</command>\n"));
        }
        
        // </setting>
        builder.append(SettingEndTag);
        
        Log.d(tag, String.format("XML Document Created : \n", builder.toString()));
        
        this.xmlDoc = builder.toString();
    }
}
