/**
 * 
 */
package iperf.project;

import java.io.InputStream;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import android.util.Log;
import android.util.Xml;

// IperfSettingParser Class
public class IperfSettingParser
{
    String tag = "IperfSettingParser";

    XmlPullParser parser = null;
    HashMap<String, IperfSetting> map = new HashMap<String, IperfSetting>();

    // �L�[����ݒ���擾
    public IperfSetting getSetting(String key)
    {
        return map.get(key);
    }
    
    // �ݒ���擾
    public HashMap<String, IperfSetting> getSettings()
    {
        return map;
    }

    // �R���X�g���N�^
    IperfSettingParser(InputStream in)
    {
        parser = Xml.newPullParser();

        // XML�t�@�C�������
        parse(in);
    }

    // XML�t�@�C�������
    private void parse(InputStream in)
    {

        IperfSetting setting = null;
        String commandType = null;
        String commandName = null;

        try
        {
            // UTF-8��XML�t�@�C���ǂݍ���
            parser.setInput(in, "UTF-8");

            // XML�I���܂Ń^�O�̎擾���J��Ԃ�
            for (int eventType = parser.getEventType(); eventType != XmlPullParser.END_DOCUMENT; eventType = parser.next())
            {
                switch (eventType)
                {
                    // �J�n�^�O
                    case XmlPullParser.START_TAG:
                        // �^�O�����擾
                        String startTag = parser.getName();
                        Log.d(tag, String.format("Start <%s>", startTag));
                        
                        // command�^�O
                        if (startTag.equals("command"))
                        {
                            // ������1�ȏ�
                            if (parser.getAttributeCount() >= 1)
                            {
                                // 1�߂̑���(�ݒ�^�C�v)���擾
                                commandType = parser.getAttributeValue(0);
                                
                                // �ݒ�^�C�v = Server
                                if (commandType.equals("Server"))
                                {
                                    // Server�ݒ�𐶐�
                                    setting = new IperfSetting(IperfSetting.SettingType.TYPE_SERVER);
                                    Log.d(tag, String.format("Setting [%s] is created", commandType));
                                }
                                // �ݒ�^�C�v = Client
                                else if (commandType.equals("Client"))
                                {
                                    // Client�ݒ�𐶐�
                                    setting = new IperfSetting(IperfSetting.SettingType.TYPE_CLIENT);
                                    Log.d(tag, String.format("Setting [%s] is created", commandType));
                                }
                                else
                                {
                                    // �s���Ȑݒ�^�C�v
                                    Log.e(tag, String.format("Unknown Command Type : %s", commandType));
                                }
                            }
                            else
                            {
                                // �ݒ�^�C�v���w�肳��Ă��Ȃ�
                                Log.e(tag, String.format("Type is not specified"));
                            }
                        }
                        // item�^�O
                        else if (startTag.equals("item"))
                        {
                            // ������1�ȏ�
                            if (parser.getAttributeCount() >= 1)
                            {
                                // 1�ڂ̑���(�ݒ薼)���擾
                                commandName = parser.getAttributeValue(0);
                            }
                            else
                            {
                                // �ݒ薼���w�肳��Ă��Ȃ�
                                Log.e(tag, String.format("Command name is not specified"));
                            }
                        }
                        break;
                    // Text
                    case XmlPullParser.TEXT:
                        // Text(�ݒ�l)���擾
                        String text = parser.getText();

                        // �󔒂݂̂�Text�͖���
                        if (text.trim().length() != 0)
                        {
                            // �ݒ荀�ڂ𐶐����Ēǉ�
                            IperfSettingItem item = new IperfSettingItem(commandName, text);
                            setting.apeendItem(item);

                            Log.d(tag, String.format("Add Item : %s = [%s]", commandName, text));
                        }
                        break;
                    // �I���^�O
                    case XmlPullParser.END_TAG:
                        // �^�O�����擾
                        String endTag = parser.getName();
                        Log.d(tag, String.format("End <%s>", endTag));
                        // command�^�O
                        if (endTag.equals("command"))
                        {
                            // �ݒ�^�C�v���L�[�Ƃ��Đݒ��HashMap�ɒǉ�
                            map.put(commandType, setting);
                            Log.d(tag, String.format("Add HasMap : %s = [%s]", commandType, setting.getType().toString()));
                        }
                        break;
                }
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.d(tag, String.format("XML Parse Error"), e);
        }
    }

}
