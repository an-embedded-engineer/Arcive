﻿using TextReplacer;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TextReplacerTest
{
    
    
    /// <summary>
    ///RegularExpressionsTest のテスト クラスです。すべての
    ///RegularExpressionsTest 単体テストをここに含めます
    ///</summary>
	[TestClass()]
	public class RegularExpressionsTest
	{


		private TestContext testContextInstance;

		/// <summary>
		///現在のテストの実行についての情報および機能を
		///提供するテスト コンテキストを取得または設定します。
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region 追加のテスト属性
		// 
		//テストを作成するときに、次の追加属性を使用することができます:
		//
		//クラスの最初のテストを実行する前にコードを実行するには、ClassInitialize を使用
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//クラスのすべてのテストを実行した後にコードを実行するには、ClassCleanup を使用
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//各テストを実行する前にコードを実行するには、TestInitialize を使用
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//各テストを実行した後にコードを実行するには、TestCleanup を使用
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///RegularExpressions コンストラクター のテスト
		///</summary>
		[TestMethod()]
		[TestProperty("Constructor1","null")]
		public void RegularExpressionsConstructorTest1()
		{
			string before = null;
			string after = null;
			RegularExpressions target = new RegularExpressions(before, after);
			Assert.IsTrue(target.Before == string.Empty);
			Assert.IsTrue(target.After == string.Empty);
		}

		/// <summary>
		///RegularExpressions コンストラクター のテスト
		///</summary>
		[TestMethod()]
		[TestProperty("Constructor2", "Empty")]
		public void RegularExpressionsConstructorTest2()
		{
			string before = string.Empty;
			string after = string.Empty;
			RegularExpressions target = new RegularExpressions(before, after);
			Assert.IsTrue(target.Before == string.Empty);
			Assert.IsTrue(target.After == string.Empty);
		}

		/// <summary>
		///RegularExpressions コンストラクター のテスト
		///</summary>
		[TestMethod()]
		[TestProperty("Constructor3", "Normal")]
		public void RegularExpressionsConstructorTest3()
		{
			string before = "aaa";
			string after = "bbb";
			RegularExpressions target = new RegularExpressions(before, after);
			Assert.IsTrue(target.Before == before);
			Assert.IsTrue(target.After == after);
		}

		/// <summary>
		///ToString のテスト
		///</summary>
		[TestMethod()]
		[TestProperty("ToString1", "null")]
		public void ToStringTest1()
		{
			string before = null;
			string after = null;
			RegularExpressions target = new RegularExpressions(before, after);
			string expected = string.Format("\"{0}\" -> \"{1}\"", "<EMPTY>", "<EMPTY>");
			string actual;
			actual = target.ToString();
			Assert.AreEqual(expected, actual);
		}

		/// <summary>
		///ToString のテスト
		///</summary>
		[TestMethod()]
		[TestProperty("ToString2", "Empty")]
		public void ToStringTest2()
		{
			string before = string.Empty;
			string after = string.Empty;
			RegularExpressions target = new RegularExpressions(before, after);
			string expected = string.Format("\"{0}\" -> \"{1}\"", "<EMPTY>", "<EMPTY>");
			string actual;
			actual = target.ToString();
			Assert.AreEqual(expected, actual);
		}

		/// <summary>
		///ToString のテスト
		///</summary>
		[TestMethod()]
		[TestProperty("ToString3", "Normal")]
		public void ToStringTest3()
		{
			string before = "aaa";
			string after = "bbb";
			RegularExpressions target = new RegularExpressions(before, after);
			string expected = string.Format("\"{0}\" -> \"{1}\"", "aaa", "bbb");
			string actual;
			actual = target.ToString();
			Assert.AreEqual(expected, actual);
		}
	}
}
