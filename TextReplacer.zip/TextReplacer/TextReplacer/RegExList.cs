﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextReplacer
{
	public delegate void ItemAppendEventHandler(RegularExpressions item);
	public delegate void ItemRemoveEventHandler(RegularExpressions item);
	public delegate void ItemClearEventHandler();

	public class RegExList
	{
		public event ItemAppendEventHandler OnItemAppend;
		public event ItemRemoveEventHandler OnItemRemove;
		public event ItemClearEventHandler OnItemClear;

		List<RegularExpressions> regexList = new List<RegularExpressions>();

		public RegularExpressions this[int index]
		{
			get
			{
				return regexList[index];
			}
		}

		public int Count
		{
			get
			{
				return regexList.Count;
			}
		}

		public RegExList()
		{
		}

		public void Append(RegularExpressions regex)
		{
			this.regexList.Add(regex);
			
			if (this.OnItemAppend != null)
			{
				OnItemAppend(regex);
			}
		}

		public void Remove(RegularExpressions regex)
		{
			this.regexList.Remove(regex);

			if (this.OnItemRemove != null)
			{
				OnItemRemove(regex);
			}
		}

		public void Clear()
		{
			this.regexList.Clear();

			if (this.OnItemClear != null)
			{
				OnItemClear();
			}
		}

		public void Save(string filePath)
		{
			Setting.Save(regexList.ToArray(), filePath);
		}

		public void Load(string filePath)
		{
			this.Clear();

			RegularExpressions[] items = Setting.Load(filePath);

			foreach (RegularExpressions item in items)
			{
				this.Append(item);
			}
		}

	}
}
