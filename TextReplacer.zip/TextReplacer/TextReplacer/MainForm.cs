﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace TextReplacer
{
	public partial class MainForm : Form
	{
		Replacer replacer;
		RegExList regexList;

		public MainForm()
		{
			InitializeComponent();
			replacer = new Replacer(this);
			regexList = new RegExList();
			regexList.OnItemAppend += new ItemAppendEventHandler(regexList_OnItemAppend);
			regexList.OnItemRemove += new ItemRemoveEventHandler(regexList_OnItemRemove);
			regexList.OnItemClear += new ItemClearEventHandler(regexList_OnItemClear);
		}

		
		void regexList_OnItemAppend(RegularExpressions item)
		{
			listReplace.Items.Add(item);
		}

		void regexList_OnItemRemove(RegularExpressions item)
		{
			listReplace.Items.Remove(item);
		}

		void regexList_OnItemClear()
		{
			listReplace.Items.Clear();
		}
		

		private void btnReplace_Click(object sender, EventArgs e)
		{
			string input = txtInput.Text;
			RegularExpressions regex = GetRegularExpression();
			
			Stopwatch sw = new Stopwatch();
			sw.Start();
			string output = replacer.Convert(input, regex);

			txtOutput.Text = output;
			sw.Stop();

			TimeSpan ts = sw.Elapsed;
			txtConvertTime.Text = ts.ToString();

		}

		private RegularExpressions GetRegularExpression()
		{
			string before = txtBeforeReplace.Text;
			string after = txtAfterReplace.Text;

			RegularExpressions regex = new RegularExpressions(before, after);
			return regex;
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			RegularExpressions regex = GetRegularExpression();
			regexList.Append(regex);

			ClearRegularExpression();

		}

		private void ClearRegularExpression()
		{
			txtBeforeReplace.Text = string.Empty;
			txtAfterReplace.Text = string.Empty;
		}

		private void btnReplaceSelected_Click(object sender, EventArgs e)
		{
			if (listReplace.SelectedItem == null)
			{
				return;
			}

			string input = txtInput.Text;
			RegularExpressions regex = listReplace.SelectedItem as RegularExpressions;
			Stopwatch sw = new Stopwatch();
			sw.Start();
			string output = replacer.Convert(input, regex);

			txtOutput.Text = output;
			sw.Stop();

			TimeSpan ts = sw.Elapsed;
			txtConvertTime.Text = ts.ToString();

		}

		private void btnReplaceAll_Click(object sender, EventArgs e)
		{
			string input = txtInput.Text;
			string output = string.Empty;

			Stopwatch sw = new Stopwatch();
			sw.Start();

			for (int i = 0; i < listReplace.Items.Count; i++)
			{
				listReplace.SelectedIndex = i;
				RegularExpressions regex = listReplace.SelectedItem as RegularExpressions;
				output = replacer.Convert(input, regex);
				input = output;
			}

			txtOutput.Text = output;
			sw.Stop();

			TimeSpan ts = sw.Elapsed;
			txtConvertTime.Text = ts.ToString();
		}

		private void btnRemoveSelected_Click(object sender, EventArgs e)
		{
			regexList.Remove(listReplace.SelectedItem as RegularExpressions);
		}

		private void btnClear_Click(object sender, EventArgs e)
		{
			regexList.Clear();
		}

		protected override bool ProcessDialogKey(Keys keyData)
		{
			switch (keyData)
			{
				case Keys.A | Keys.Control:
					if (this.ActiveControl is TextBox)
					{
						TextBox txt = this.ActiveControl as TextBox;
						txt.SelectionStart = 0;
						txt.SelectionLength = txt.Text.Length;
						return true;
					}
					break;
			}

			return base.ProcessDialogKey(keyData);
		}

		private void miSaveSetting_Click(object sender, EventArgs e)
		{
			SaveFileDialog dlg = new SaveFileDialog();
			
			dlg.InitialDirectory = Environment.CurrentDirectory;
			dlg.Filter = "XMLファイル(*.xml)|*.xml|すべてのファイル(*.*)|*.*";
			dlg.Title = "ファイルに保存";
			dlg.CheckPathExists = true;
			dlg.RestoreDirectory = true;
			dlg.OverwritePrompt = true;

			if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				regexList.Save(dlg.FileName);
			}
		}

		private void miLoadSetting_Click(object sender, EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();

			dlg.InitialDirectory = Environment.CurrentDirectory;
			dlg.Filter = "XMLファイル(*.xml)|*.xml|すべてのファイル(*.*)|*.*";
			dlg.Title = "ファイルに保存";
			dlg.CheckPathExists = true;
			dlg.RestoreDirectory = true;

			if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				regexList.Load(dlg.FileName);
			}
		}
	}
}
