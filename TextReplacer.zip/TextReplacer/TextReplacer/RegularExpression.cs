﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TextReplacer
{
	/// <summary>
	/// RegularExpressions Class
	/// </summary>
	public class RegularExpressions
	{
		string[] escapeAfter = { "\n", "\r", "\t", "\f" };
		string[] escapeBefore = { @"\\n", @"\\r", @"\\t", @"\\f"};

		/// <summary>
		/// 検索式
		/// </summary>
		public string Before { get; private set; }
		/// <summary>
		/// 置換式
		/// </summary>
		public string After { get; private set; }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="before">検索式</param>
		/// <param name="after">置換式</param>
		public RegularExpressions(string before, string after)
		{
			// nullの場合は空文字列に変換
			this.Before = (before != null) ? before : string.Empty;
			this.After = (after != null) ? after : string.Empty;

			for (int i = 0; i < escapeBefore.Length; i++)
			{
				this.Before = Regex.Replace(this.Before, escapeBefore[i], escapeAfter[i]); 
			}

			for (int i = 0; i < escapeBefore.Length; i++)
			{
				this.After = Regex.Replace(this.After, escapeBefore[i], escapeAfter[i]);
			}
		}

		/// <summary>
		/// 文字列に変換
		/// </summary>
		/// <returns>検索式/置換式</returns>
		public override string ToString()
		{
			// 空文字列の場合は表示を変換
			string before = (this.Before != string.Empty) ? this.Before : "<EMPTY>";
			string after = (this.After != string.Empty) ? this.After : "<EMPTY>";

			return string.Format("\"{0}\" -> \"{1}\"", before, after);
		}
	}
}
