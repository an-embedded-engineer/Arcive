﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;

namespace TextReplacer
{
	public class Replacer
	{
		public int LineCount
		{
			get;
			private set;
		}

		public Form Parent
		{
			get;
			private set;
		}

		public Replacer(Form parent)
		{
			this.Parent = parent;
		}

		public string Convert(string input, RegularExpressions regex)
		{
			BackgroundWorkerArguments argument = new BackgroundWorkerArguments(input, regex);
			ProgressDialog pd = new ProgressDialog(new DoWorkEventHandler(Worker_DoWork), argument);

			DialogResult result = pd.ShowDialog(this.Parent);

			string resultString = null;

			switch (result)
			{
				case DialogResult.Cancel:
					break;
				case DialogResult.Abort:
					Exception ex = pd.Error;
					MessageBox.Show("Error: " + ex.Message);
					break;
				case DialogResult.OK:
					resultString = pd.Result as string;
					break;
			}

			pd.Dispose();

			return resultString;
		}

		void Worker_DoWork(object sender, DoWorkEventArgs e)
		{
			BackgroundWorkerArguments arg = e.Argument as BackgroundWorkerArguments;
			BackgroundWorker bw = sender as BackgroundWorker;
			StringReader sr = new StringReader(arg.InputText);
			StringBuilder br = new StringBuilder();

			string input = null;

			this.LineCount = arg.InputText.ToList().Where(c => c.Equals('\n')).Count() + 1;
			int reportInterval = (LineCount / 1000);
			if (reportInterval == 0)
			{
				reportInterval = 1;
			}
			int count = 0;

			while ((input = sr.ReadLine()) != null)
			{
				if (bw.CancellationPending)
				{
					e.Cancel = true;
					return;
				}

				string output = Regex.Replace(input, arg.RegEx.Before, arg.RegEx.After);
				br.Append(output + "\r\n");

				count++;
				
				if (count % reportInterval == 0)
				{
					double percent = ((double)count / LineCount) * 100;
					bw.ReportProgress((int)percent, string.Format("進捗 : {0} / {1} lines = {2}%", count, LineCount, (int)percent));
				}
			}

			bw.ReportProgress(100, string.Format("進捗 : {0} / {1} lines = {2:}%", count, LineCount, 100));
			// 結果をセット
			e.Result = br.ToString();
		}
	}

	public class BackgroundWorkerArguments
	{
		public RegularExpressions RegEx
		{
			get;
			private set;
		}

		public String InputText
		{
			get;
			private set;
		}

		public BackgroundWorkerArguments(string input, RegularExpressions regex)
		{
			this.InputText = input;
			this.RegEx = regex;
		}
	}

}
