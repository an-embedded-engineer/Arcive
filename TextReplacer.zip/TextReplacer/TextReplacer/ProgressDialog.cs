﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TextReplacer
{
	public partial class ProgressDialog : Form
	{
		public BackgroundWorker Worker
		{
			get;
			private set;
		}

		public object Result
		{
			get;
			private set;
		}

		public Exception Error
		{
			get;
			private set;
		}

		public object Argument
		{
			get;
			private set;
		}

		public ProgressDialog(DoWorkEventHandler handler) : this(handler, null)
		{
		}

		public ProgressDialog(DoWorkEventHandler handler, object arg)
		{
			InitializeComponent();

			// Argumentを設定
			this.Argument = arg;

			this.Worker = new BackgroundWorker();

			// 進捗報告を有効
			this.Worker.WorkerReportsProgress = true;
			// キャンセル可能
			this.Worker.WorkerSupportsCancellation = true;
			// イベントハンドラを登録
			this.Worker.DoWork += handler;
			this.Worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
			this.Worker.ProgressChanged += new ProgressChangedEventHandler(worker_ProgressChanged);

			this.Shown += new EventHandler(ProgressDialog_Shown);

		}

		void ProgressDialog_Shown(object sender, EventArgs e)
		{
			this.Worker.RunWorkerAsync(this.Argument);
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.btnCancel.Enabled = false;
			this.Worker.CancelAsync();
		}

		void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
		{
			if (e.ProgressPercentage < this.progressBar.Minimum)
			{
				progressBar.Value = progressBar.Minimum;
			}
			else if (progressBar.Maximum < e.ProgressPercentage)
			{
				progressBar.Value = progressBar.Maximum;
			}
			else
			{
				this.progressBar.Value = e.ProgressPercentage;
			}

			this.labelProgress.Text = (string)e.UserState;

		}

		void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (e.Error != null)
			{
				MessageBox.Show(this, "Error", e.Error.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
				this.Error = e.Error;
				this.DialogResult = System.Windows.Forms.DialogResult.Abort;
			}
			else if (e.Cancelled)
			{
				this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			}
			else
			{
				this.Result = e.Result;
				this.DialogResult = System.Windows.Forms.DialogResult.OK;
			}

			this.Close();
		}
	}
}
