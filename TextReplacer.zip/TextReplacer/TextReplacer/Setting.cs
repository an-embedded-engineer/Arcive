﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace TextReplacer
{
	public static class Setting
	{
		public static void Save(RegularExpressions[] items, string filePath)
		{
			XDeclaration dec = new XDeclaration("1.0", "UTF-8", "yes");

			XElement setting = new XElement("Setting");

			foreach (RegularExpressions item in items)
			{
				XElement xbefore = new XElement("before", item.Before);
				XElement xafter = new XElement("after", item.After);

				XElement xitem = new XElement("item");
				xitem.Add(xbefore);
				xitem.Add(xafter);

				setting.Add(xitem);
			}

			XDocument doc = new XDocument(dec, setting);

			doc.Save(filePath);
		}

		public static RegularExpressions[] Load(string filePath)
		{
			List<RegularExpressions> items = new List<RegularExpressions>();

			XElement setting = XElement.Load(filePath, LoadOptions.PreserveWhitespace);

			var xitems = from xitem in setting.Elements("item")
						 select new RegularExpressions(
							 xitem.Element("before").Value,
							 xitem.Element("after").Value);

			items.AddRange(xitems);

			return items.ToArray();
		}

	}
}
