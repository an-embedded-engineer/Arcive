﻿namespace TextReplacer
{
	partial class MainForm
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.ファイルFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.miSaveSetting = new System.Windows.Forms.ToolStripMenuItem();
			this.miLoadSetting = new System.Windows.Forms.ToolStripMenuItem();
			this.txtInput = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtOutput = new System.Windows.Forms.TextBox();
			this.txtBeforeReplace = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtAfterReplace = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnReplace = new System.Windows.Forms.Button();
			this.listReplace = new System.Windows.Forms.ListBox();
			this.btnReplaceSelected = new System.Windows.Forms.Button();
			this.btnReplaceAll = new System.Windows.Forms.Button();
			this.btnRemoveSelected = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.txtConvertTime = new System.Windows.Forms.TextBox();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 26);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 12);
			this.label1.TabIndex = 0;
			this.label1.Text = "入力文字列 :";
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルFToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(939, 26);
			this.menuStrip1.TabIndex = 1;
			this.menuStrip1.Text = "menuStrip";
			// 
			// ファイルFToolStripMenuItem
			// 
			this.ファイルFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miSaveSetting,
            this.miLoadSetting});
			this.ファイルFToolStripMenuItem.Name = "ファイルFToolStripMenuItem";
			this.ファイルFToolStripMenuItem.Size = new System.Drawing.Size(85, 22);
			this.ファイルFToolStripMenuItem.Text = "ファイル(&F)";
			// 
			// miSaveSetting
			// 
			this.miSaveSetting.Name = "miSaveSetting";
			this.miSaveSetting.Size = new System.Drawing.Size(152, 22);
			this.miSaveSetting.Text = "保存(&S)";
			this.miSaveSetting.Click += new System.EventHandler(this.miSaveSetting_Click);
			// 
			// miLoadSetting
			// 
			this.miLoadSetting.Name = "miLoadSetting";
			this.miLoadSetting.Size = new System.Drawing.Size(152, 22);
			this.miLoadSetting.Text = "読込み(&L)";
			this.miLoadSetting.Click += new System.EventHandler(this.miLoadSetting_Click);
			// 
			// txtInput
			// 
			this.txtInput.Location = new System.Drawing.Point(13, 42);
			this.txtInput.MaxLength = 2147483647;
			this.txtInput.Multiline = true;
			this.txtInput.Name = "txtInput";
			this.txtInput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtInput.Size = new System.Drawing.Size(630, 284);
			this.txtInput.TabIndex = 2;
			this.txtInput.WordWrap = false;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(13, 338);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(71, 12);
			this.label2.TabIndex = 0;
			this.label2.Text = "出力文字列 :";
			// 
			// txtOutput
			// 
			this.txtOutput.Location = new System.Drawing.Point(14, 354);
			this.txtOutput.MaxLength = 2147483647;
			this.txtOutput.Multiline = true;
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtOutput.Size = new System.Drawing.Size(630, 284);
			this.txtOutput.TabIndex = 2;
			this.txtOutput.WordWrap = false;
			// 
			// txtBeforeReplace
			// 
			this.txtBeforeReplace.Location = new System.Drawing.Point(651, 42);
			this.txtBeforeReplace.Name = "txtBeforeReplace";
			this.txtBeforeReplace.Size = new System.Drawing.Size(276, 19);
			this.txtBeforeReplace.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(649, 26);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(47, 12);
			this.label3.TabIndex = 4;
			this.label3.Text = "置換前 :";
			// 
			// txtAfterReplace
			// 
			this.txtAfterReplace.Location = new System.Drawing.Point(651, 81);
			this.txtAfterReplace.Name = "txtAfterReplace";
			this.txtAfterReplace.Size = new System.Drawing.Size(276, 19);
			this.txtAfterReplace.TabIndex = 3;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(649, 65);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(47, 12);
			this.label4.TabIndex = 4;
			this.label4.Text = "置換後 :";
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(651, 107);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(131, 23);
			this.btnAdd.TabIndex = 5;
			this.btnAdd.Text = "追加";
			this.btnAdd.UseVisualStyleBackColor = true;
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnReplace
			// 
			this.btnReplace.Location = new System.Drawing.Point(788, 106);
			this.btnReplace.Name = "btnReplace";
			this.btnReplace.Size = new System.Drawing.Size(139, 23);
			this.btnReplace.TabIndex = 5;
			this.btnReplace.Text = "実行";
			this.btnReplace.UseVisualStyleBackColor = true;
			this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
			// 
			// listReplace
			// 
			this.listReplace.FormattingEnabled = true;
			this.listReplace.ItemHeight = 12;
			this.listReplace.Location = new System.Drawing.Point(651, 158);
			this.listReplace.Name = "listReplace";
			this.listReplace.Size = new System.Drawing.Size(276, 268);
			this.listReplace.TabIndex = 6;
			// 
			// btnReplaceSelected
			// 
			this.btnReplaceSelected.Location = new System.Drawing.Point(651, 433);
			this.btnReplaceSelected.Name = "btnReplaceSelected";
			this.btnReplaceSelected.Size = new System.Drawing.Size(131, 23);
			this.btnReplaceSelected.TabIndex = 5;
			this.btnReplaceSelected.Text = "選択実行";
			this.btnReplaceSelected.UseVisualStyleBackColor = true;
			this.btnReplaceSelected.Click += new System.EventHandler(this.btnReplaceSelected_Click);
			// 
			// btnReplaceAll
			// 
			this.btnReplaceAll.Location = new System.Drawing.Point(788, 432);
			this.btnReplaceAll.Name = "btnReplaceAll";
			this.btnReplaceAll.Size = new System.Drawing.Size(139, 23);
			this.btnReplaceAll.TabIndex = 5;
			this.btnReplaceAll.Text = "全実行";
			this.btnReplaceAll.UseVisualStyleBackColor = true;
			this.btnReplaceAll.Click += new System.EventHandler(this.btnReplaceAll_Click);
			// 
			// btnRemoveSelected
			// 
			this.btnRemoveSelected.Location = new System.Drawing.Point(651, 462);
			this.btnRemoveSelected.Name = "btnRemoveSelected";
			this.btnRemoveSelected.Size = new System.Drawing.Size(131, 23);
			this.btnRemoveSelected.TabIndex = 5;
			this.btnRemoveSelected.Text = "選択削除";
			this.btnRemoveSelected.UseVisualStyleBackColor = true;
			this.btnRemoveSelected.Click += new System.EventHandler(this.btnRemoveSelected_Click);
			// 
			// btnClear
			// 
			this.btnClear.Location = new System.Drawing.Point(788, 461);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(139, 23);
			this.btnClear.TabIndex = 5;
			this.btnClear.Text = "全削除";
			this.btnClear.UseVisualStyleBackColor = true;
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(649, 498);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(63, 12);
			this.label5.TabIndex = 7;
			this.label5.Text = "変換時間 : ";
			// 
			// txtConvertTime
			// 
			this.txtConvertTime.BackColor = System.Drawing.SystemColors.Window;
			this.txtConvertTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtConvertTime.Location = new System.Drawing.Point(718, 495);
			this.txtConvertTime.Name = "txtConvertTime";
			this.txtConvertTime.ReadOnly = true;
			this.txtConvertTime.Size = new System.Drawing.Size(209, 19);
			this.txtConvertTime.TabIndex = 8;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(939, 647);
			this.Controls.Add(this.txtConvertTime);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.listReplace);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnRemoveSelected);
			this.Controls.Add(this.btnReplaceAll);
			this.Controls.Add(this.btnReplaceSelected);
			this.Controls.Add(this.btnReplace);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtAfterReplace);
			this.Controls.Add(this.txtBeforeReplace);
			this.Controls.Add(this.txtOutput);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtInput);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "MainForm";
			this.Text = "置換君";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem ファイルFToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem miSaveSetting;
		private System.Windows.Forms.ToolStripMenuItem miLoadSetting;
		private System.Windows.Forms.TextBox txtInput;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtOutput;
		private System.Windows.Forms.TextBox txtBeforeReplace;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtAfterReplace;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnReplace;
		private System.Windows.Forms.ListBox listReplace;
		private System.Windows.Forms.Button btnReplaceSelected;
		private System.Windows.Forms.Button btnReplaceAll;
		private System.Windows.Forms.Button btnRemoveSelected;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtConvertTime;
	}
}

